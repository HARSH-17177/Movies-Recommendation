import express from "express";
const router = express.Router();
import {
  registerEmployer,
  loginEmployer,
  sendOTP,
  getEmployerID,
  changePassword,
  resetEmployerPassword,
  resetEmployerPasswordToken,
} from "../controllers/authEmployer.js";
// import { auth } from "../middleware/authMiddleware.js";

//SIGNUP ROUTE FOR EMPLOYER
router.route("/registerEmployer").post(registerEmployer);
//LOGIN ROUTE FOR CANDIDATE
router.route("/loginEmployer").post(loginEmployer);

//  GET CURRENT USER
// router.get("/currentUser", auth, currentUserController);

//to get otp
router.post("/sendOtp", sendOTP);
//change password
router.post("/changePassword", changePassword);
//getting the employer ID
router.post("/employerUserID", getEmployerID);
//reset password token
router.post("/reset-password-token-employer", resetEmployerPasswordToken);
//reset password
router.post("/reset-password-employer", resetEmployerPassword);

export default router;
