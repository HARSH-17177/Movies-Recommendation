import express from "express";
import {
  getEmployerList,
  createEmployer,
  updateEmployer,
  deleteEmployer,
  getEmployerDetails,
  createJobPosting,
  getCandidatesForJobListing,
  getPostedJobs,
  getLatestJobApplicants,
  toggleShortlistStatus,
  getShortlistedCandidates,
  getEmployerStats,
  toggleInterviewStatus,
  logoController,
} from "../controllers/employerList.js";
const router = express.Router();

router.route("/EmployerList").get(getEmployerList);
router.route("/Employer/new").post(createEmployer);
router
  .route("/Employer/:id")
  .put(updateEmployer)
  .delete(deleteEmployer)
  .get(getEmployerDetails);

router.route("/Employer/newJobPosting").post(createJobPosting);

router.post("/job/candidates", getCandidatesForJobListing);

router.post("/EmpDash", getLatestJobApplicants);

router.get("/jobsPosted/:employerId/postedJobs", getPostedJobs);

router.put("/shortlistedCandidates", toggleShortlistStatus);

router.post("/getShortlistedCandidates", getShortlistedCandidates);

router.post("/getEmployerStats", getEmployerStats);

router.post("/changeStatus", toggleInterviewStatus);

router.post("/getLogoUploadLink", logoController);

export default router;
