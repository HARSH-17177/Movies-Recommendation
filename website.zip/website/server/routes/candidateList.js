import express from "express";
import {
  getCandidateList,
  createCandidate,
  updateCandidate,
  deleteCandidate,
  getCandidateDetails,
  jobApplicationController,
  allJobPostings,
  getAppliedJobs,
  imageController,
  resumeController,
  getJobDetails,
  addToWishlist,
  getCandidate,
  storeScore,
  getCandidateStats,
  getShortlistedJobs,
} from "../controllers/candidateList.js";
import { auth } from "../middleware/authMiddleware.js";
const router = express.Router();

router.route("/CandidateList").get(getCandidateList);
router.route("/Candidate/new").post(createCandidate);
router
  .route("/Candidate/:id")
  .put(updateCandidate)
  .delete(deleteCandidate)
  .get(getCandidateDetails);
router.route("/Candidate/applyJob").post(jobApplicationController);

router.route("/jobPostings").get(allJobPostings);

router.get("/appliedJobs/:candidateId/jobs", getAppliedJobs);

router.post("/image-url", imageController);

router.post("/resume-url", resumeController);

router.get("/job-details/:jobListingId", getJobDetails);

router.put("/wishlist", addToWishlist);

router.post("/candidateDetails", getCandidate);

router.post("/storeMCQScore", storeScore);

router.post("/getCandidateStats", getCandidateStats);

router.post("/getShortlistedJobs", getShortlistedJobs);

export default router;
