import express from "express";
const router = express.Router();
import {
  registerCandidate,
  loginCandidate,
  currentUserController,
  getAllNotificationController,
  getUserID,
  changePasswordCandidate,
  sendCandidateOTP,
} from "../controllers/authCandidate.js";
import {
  resetPasswordToken,
  resetPassword,
} from "../controllers/resetPassword.js";
import { auth } from "../middleware/authMiddleware.js";

//SIGNUP ROUTE FOR CANDIDATE
router.route("/registerCandidate").post(registerCandidate);
//LOGIN ROUTE FOR CANDIDATE
router.route("/loginCandidate").post(loginCandidate);
//  GET CURRENT USER
router.get("/currentUser", auth, currentUserController);
//GET NOTIFICATIONS OF CANDIDATE
router.post("/getAllNotification", auth, getAllNotificationController);
//get the userID
router.post("/UserID", getUserID);
//reset password token
router.post("/reset-password-token", resetPasswordToken);
//reset password
router.post("/reset-password", resetPassword);
//change password
router.post("/changePasswordCandidate", changePasswordCandidate);
//to get otp
router.post("/sendCandidateOtp", sendCandidateOTP);
export default router;
