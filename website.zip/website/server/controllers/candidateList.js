import candidateModel from "../mongodb/models/candidateDetails.js";
import jobApplication from "../mongodb/models/jobApplication.js";
import jobListing from "../mongodb/models/jobListing.js";
import ErrorHandler from "../utils/errorhandler.js";
import catchAsyncErrors from "../middleware/catchAsyncErrors.js";
import generateSignedUrl from "../AWS/s3.js";
import generateSignedUrlResume from "../AWS/resumeS3.js";
import mongoose from "mongoose";
mongoose.connection.useDb("test");
//GETTING ALL THE CANDIDATES ALONG WITH THE DETAILS
export const getCandidateList = catchAsyncErrors(async (req, res) => {
  const candidateList = await candidateModel.find();
  res.status(200).json({
    status: "success",
    candidateList,
  });
});
//CREATING A CANDIDATE PROFILE
export const createCandidate = catchAsyncErrors(async (req, res, next) => {
  const Candidate = await candidateModel.create(req.body);

  res.status(201).json({
    success: true,
    Candidate,
  });
});
//UPDATING CANDIDATE PROFILE
export const updateCandidate = catchAsyncErrors(async (req, res) => {
  let candidate = await candidateModel.findById(req.params.id);
  if (!foundCandidate) {
    return next(new ErrorHandler("Candidate Not found", 404));
  }
  candidate = await candidateModel.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
    useFindAndModify: false,
  });
  res.status(200).json({
    success: true,
    candidate,
  });
});
//DELETING CANDIDATE PROFILE
export const deleteCandidate = catchAsyncErrors(async (req, res, next) => {
  let foundCandidate = await candidateModel.findById(req.params.id);
  if (!foundCandidate) {
    return next(new ErrorHandler("Candidate Not found", 404));
  }

  await foundCandidate.deleteOne();
  res.status(200).json({
    success: true,
    message: "Candidate deleted successfully",
  });
});
//GETTING DETAILS OF A PARTICULAR CANDIDATE ON EMPLOYER SIDE
export const getCandidateDetails = catchAsyncErrors(async (req, res, next) => {
  const foundCandidate = await candidateModel.findById(req.params.id);

  if (!foundCandidate) {
    return next(new ErrorHandler("Candidate Not found", 404));
  }

  res.status(200).json({
    success: true,
    foundCandidate,
  });
});
//For applying to a job
export const jobApplicationController = catchAsyncErrors(
  async (req, res, next) => {
    req.body.status = "pending";
    const userid = req.body.candidate;
    const jobId = req.body.job_listing;
    const employer_id = req.body.employer;

    // Candidate has not applied, proceed to create a new job application
    let applicant = await candidateModel.findOne({ user: userid });
    const id = applicant._id;
    // Check if the candidate has already applied
    const existingApplication = await jobApplication.findOne({
      job_listing: jobId,
      candidate: id,
      employer: employer_id,
    });

    if (existingApplication) {
      // Candidate has already applied
      return res.status(409).json({
        success: false,
        message: "You have already applied for this job",
      });
    }
    const newJobApplication = await jobApplication.create({
      job_listing: jobId,
      candidate: id,
      employer: employer_id,
    });

    res.status(201).json({
      success: true,
      message: "New job application successful",
      newJobApplication,
    });
  }
);

//to get all the job postings for the candidate to apply
export const allJobPostings = catchAsyncErrors(async (req, res) => {
  const jobList = await jobListing.find({}).populate({
    path: "companyName",
    select: "brandName logoUrl", // Specify the fields you want to select from the referenced model
  });
  res.status(200).json({
    status: "success",
    jobList,
  });
});
//list of jobs to which a candidate has applied
export const getAppliedJobs = catchAsyncErrors(async (req, res) => {
  const candidateId = req.params.candidateId;
  let applicant = await candidateModel.findOne({ user: candidateId });
  const id = applicant._id;
  const applied = await jobApplication.find({ candidate: id }).populate({
    path: "job_listing",
    populate: {
      path: "companyName",
      model: "EmployerDetails",
      select: "brandName",
    },
  });

  if (!applied) {
    return next(new ErrorHandler("candidate not found", 404));
  }
  res.json(applied);
});

export const imageController = async (request, response) => {
  const url = await generateSignedUrl(request.body.name, request.body.token);
  response.status(200).json({ url });
};

export const resumeController = async (request, response) => {
  const url = await generateSignedUrlResume(request.body.token);
  response.status(200).json({ url });
};

// Function to get job details for a specific job listing
export const getJobDetails = catchAsyncErrors(async (req, res, next) => {
  const jobListingId = req.params.jobListingId;

  // Find the job listing by its ID
  const jobDetails = await jobListing.findById(jobListingId);

  if (!jobDetails) {
    return next(new ErrorHandler("Job Listing Not Found", 404));
  }

  res.status(200).json({
    success: true,
    jobDetails,
  });
});
// Add to wishlist functionality
export const addToWishlist = catchAsyncErrors(async (req, res, next) => {
  const _id = req.body.userId;
  const { jobId } = req.body;

  const foundCandidate = await candidateModel.findOne({ user: _id });
  if (!foundCandidate) {
    return next(new ErrorHandler("Candidate Not found", 404));
  }
  const alreadyAdded = foundCandidate.wishlist.find(
    (id) => id.toString() === jobId
  );
  if (alreadyAdded) {
    let user = await candidateModel.findOneAndUpdate(
      { user: _id },
      {
        $pull: { wishlist: jobId },
      },
      {
        new: true,
      }
    );
    res.status(200).json(user);
  } else {
    let user = await candidateModel.findOneAndUpdate(
      { user: _id },
      {
        $push: { wishlist: jobId },
      },
      {
        new: true,
      }
    );
    res.status(200).json(user);
  }
});

//GETTING DETAILS OF A PARTICULAR CANDIDATE ON CANDIDATE SIDE
export const getCandidate = catchAsyncErrors(async (req, res, next) => {
  console.log(req.body.user);
  let user = req.body.user;
  const foundCandidate = await candidateModel.findOne({ user: user });

  if (!foundCandidate) {
    return next(new ErrorHandler("Candidate Not found", 404));
  }

  res.status(200).json({
    success: true,
    foundCandidate,
  });
});
//To store the score of the stage 2 MCQ in mongodb
export const storeScore = catchAsyncErrors(async (req, res, next) => {
  try {
    const user = req.body.user;
    const scoreExcel = req.body.scoreExcel;
    const scoreReasoning = req.body.scoreReasoning;
    const scoreAnalytical = req.body.scoreAnalytical;
    const updatedDetails = await candidateModel.findOneAndUpdate(
      { user: user },
      {
        scoreExcel: scoreExcel,
        scoreReasoning: scoreReasoning,
        scoreAnalytical: scoreAnalytical,
      }
    );
    return res.status(200).json({
      success: true,
      message: "Score Stored successfully",
    });
  } catch (error) {
    console.log(error.message);
    return res.status(500).json({
      success: false,
      message: "Something went wrong while storing score",
    });
  }
});

//To get the statistics related to the candidate
export const getCandidateStats = catchAsyncErrors(async (req, res, next) => {
  const candidateId = req.body.id;
  const Id = await candidateModel.findOne({ user: candidateId }, "_id");
  // Get total number of job applications for the candidate
  const totalJobApplications = await jobApplication.countDocuments({
    candidate: Id,
  });

  // Get total number of job listings where the candidate has been shortlisted
  const shortlistedJobListings = await jobListing.countDocuments({
    shortlistedCandidates: { $in: [candidateId] },
  });

  // Get total number of job listings where the candidate status is "pending" or "Interview"
  const jobListingsWithStatus = await jobApplication.countDocuments({
    candidate: Id,
    status: { $in: ["pending", "Interview"] },
  });

  const noOfInterview = await jobApplication.countDocuments({
    candidate: Id,
    status: { $in: ["Interview"] },
  });

  const response = {
    totalJobApplications,
    totalShortlistedJobListings: shortlistedJobListings,
    totalJobListingsWithActiveStatus: jobListingsWithStatus,
    noOfInterviews: noOfInterview,
  };

  res.status(200).json({
    success: true,
    data: response,
  });
});

//to get the shortlisted jobs for a candidate
export const getShortlistedJobs = async (req, res, next) => {
  try {
    const userId = req.body.id;

    // Find the candidate details by user ID
    const candidateDetails = await candidateModel.findOne({ user: userId });

    if (!candidateDetails) {
      return res
        .status(404)
        .json({ success: false, message: "Candidate details not found" });
    }

    // Get the job listings based on the shortlistedCandidates array
    const shortlistedJobIds = candidateDetails.wishlist;
    const shortlistedJobs = await jobListing
      .find({ _id: { $in: shortlistedJobIds } })
      .exec();

    res.status(200).json({
      success: true,
      shortlistedJobs,
    });
  } catch (error) {
    console.error(error);
    next(error);
  }
};
