import { mailSender } from "../utils/mailSender.js";
import candidateDetails from "../mongodb/models/candidateDetails.js";
import candidateSignUp from "../mongodb/models/candidateRegister.js";
import bcrypt from "bcryptjs";
import mongoose from "mongoose";
import crypto from "crypto";
mongoose.connection.useDb("test");

//reset password token
export const resetPasswordToken = async (req, res) => {
  try {
    let userEmail = req.body.email;

    const user = await candidateSignUp.findOne({ email: userEmail });
    if (!user) {
      return res.status(401).json({
        success: false,
        message: "Your email is not registered with us",
      });
    }
    const token = crypto.randomUUID();
    console.log("The token is:", token);
    const updatedDetails = await candidateSignUp.findOneAndUpdate(
      { email: userEmail },
      {
        token: token,
        resetPasswordExpires: Date.now() + 5 * 60 * 1000,
      },
      {
        new: true,
      }
    );
    const url = `http://localhost:3000/update-password/${token}`;
    await mailSender(
      userEmail,
      "Password Reset Link",
      `passoword reset link:${url}`
    );

    return res.status(200).json({
      success: true,
      message: "Email sent successfully, please check email and change pwd",
    });
  } catch (error) {
    console.log(error.message);
    return res.status(500).json({
      success: false,
      message: "Something went wrong while resetting the password",
    });
  }
};

//reset password
export const resetPassword = async (req, res) => {
  try {
    const { password, confirmPassword, token } = req.body;
    if (password !== confirmPassword) {
      return res.json({
        success: false,
        message: "password not matching",
      });
    }
    const userDetails = await candidateSignUp.findOne({ token: token });
    if (!userDetails) {
      res.status(404).json({
        success: false,
        message: "Token is invalid",
      });
    }
    if (userDetails.resetPasswordExpires < Date.now()) {
      return res.json({
        success: false,
        message: "Token expired",
      });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const candidate = await candidateSignUp.findOne({ token });
    if (!candidate) {
      return res.status(404).json({ message: "Candidate not found" });
    }
    // Update the password in the candidateSignUp model
    await candidateSignUp.updateOne(
      { _id: candidate._id },
      { $set: { password: hashedPassword } },
      { new: true }
    );
    return res.status(200).send({
      success: true,
      message: "Password updated Successfully!",
    });
  } catch (error) {
    console.log(error.message);
    res.status(500).send({
      success: false,
      message: "Error occurred when updating Password.",
    });
  }
};
