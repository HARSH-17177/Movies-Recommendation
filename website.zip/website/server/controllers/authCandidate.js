import candidateSignUp from "../mongodb/models/candidateRegister.js";
import catchAsyncErrors from "../middleware/catchAsyncErrors.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import OTP from "../mongodb/models/OTP.js";
import otpGenerator from "otp-generator";
import mongoose from "mongoose";

mongoose.connection.useDb("test");

// Send OTP for Candidate
export const sendCandidateOTP = catchAsyncErrors(async (req, res, next) => {
  const { email } = req.body;

  // Check if candidate already exists
  const checkCandidateExist = await candidateSignUp.findOne({ email });

  if (checkCandidateExist) {
    return res.status(401).send({
      success: false,
      message: "Candidate already exists",
    });
  }

  // Generate OTP
  var otp = otpGenerator.generate(6, {
    upperCaseAlphabets: false,
    lowerCaseAlphabets: false,
    specialChars: false,
  });

  console.log("Candidate OTP generated:", otp);

  // Check unique OTP or not
  let result = await OTP.findOne({ otp: otp });

  while (result) {
    otp = otpGenerator.generate(6, {
      upperCaseAlphabets: false,
      lowerCaseAlphabets: false,
      specialChars: false,
    });
    result = await OTP.findOne({ otp: otp });
  }

  // Save the new OTP to the database
  const otpPayload = { email, otp };
  const otpBody = await OTP.create(otpPayload);
  console.log(otpBody);

  // Return response successfully
  res.status(200).send({
    success: true,
    message: "Candidate OTP sent successfully",
    otp,
  });
});

// Candidate Signup
export const registerCandidate = catchAsyncErrors(async (req, res, next) => {
  const { email, password, otp } = req.body;

  if (!email || !password || !otp) {
    return res.status(403).json({
      success: false,
      message: "All fields are required",
    });
  }

  const existingCandidate = await candidateSignUp.findOne({ email });

  if (existingCandidate) {
    return res.status(400).send({
      success: false,
      message: "Candidate already exists",
    });
  }

  // Find most recent OTP stored for the candidate
  const recentOTP = await OTP.find({ email }).sort({ createdAt: -1 }).limit(1);

  console.log("Candidate OTP:", recentOTP[0]);

  // Validate OTP
  if (recentOTP.length === 0) {
    return res.status(400).send({
      success: false,
      message: "OTP not found",
    });
  } else if (otp !== recentOTP[0].otp) {
    return res.status(400).send({
      success: false,
      message: "OTP not matching",
    });
  }

  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(req.body.password, salt);
  req.body.password = hashedPassword;

  const candidateRegistered = await candidateSignUp.create(req.body);

  // Generate a JWT token
  const token = jwt.sign(
    { id: candidateRegistered._id, role: "Student" },
    process.env.JWT_SECRET,
    {
      expiresIn: "1d",
    }
  );

  // Remove sensitive information from the user object
  const userResponse = {
    _id: candidateRegistered._id,
    email: candidateRegistered.email,
    // Add any other user details you want to include in the response
  };

  // Send the response with the token and user details
  res.status(201).json({
    success: true,
    token,
    user: userResponse,
    message: "Signup successful",
  });
});

//CANDIDATE LOGIN
export const loginCandidate = catchAsyncErrors(async (req, res, next) => {
  let user = await candidateSignUp.findOne({ email: req.body.email });
  if (!user) {
    return res.status(200).send({
      success: false,
      message: "User Not found",
    });
  }
  const isMatch = await bcrypt.compare(req.body.password, user.password);
  if (!isMatch) {
    return res.status(200).send({
      success: false,
      message: "Invalid Email or Password ",
    });
  }
  const token = jwt.sign(
    { id: user._id, role: "Student" },
    process.env.JWT_SECRET,
    {
      expiresIn: "1d",
    }
  );
  user = user.toObject();
  user.token = token;
  user.password = undefined;
  // const options = {
  //   expires: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
  //   // httpOnly: true,
  // };
  res.status(200).json({
    success: true,
    token,
    user,
    message: "Logged in successfully",
  });
});
//GET CURRENT USER
export const currentUserController = catchAsyncErrors(async (req, res) => {
  try {
    const user = await candidateSignUp.findOne({ _id: req.body.userId });
    return res.status(200).send({
      success: true,
      message: "User fetched successfully",
      user,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({
      success: false,
      message: "unable to get current user",
      error,
    });
  }
});

//NOTIFICATION CONTROLLER
export const getAllNotificationController = catchAsyncErrors(
  async (req, res) => {
    try {
      const user = await candidateSignUp.findOne({ _id: req.body.userId });
      const seenNotification = user.seennotification;
      const notification = user.notification;
      seenNotification.push(...notification);
      user.notification = [];
      user.seennotification = notification;
      const updatedUser = await user.save();
      res.status(200).send({
        success: true,
        message: "All notifications are marked as read",
        data: updatedUser,
      });
    } catch (error) {
      console.log(error);
      res.status(500).send({
        message: "Error in notification",
        success: false,
        error,
      });
    }
  }
);

export const getUserID = catchAsyncErrors(async (req, res) => {
  try {
    let tok = req.body.token;
    jwt.verify(tok, process.env.JWT_SECRET, (err, decode) => {
      if (err) {
        console.log("Failed to authorize");
        return;
      } else {
        let userId = decode.id;
        res.status(200).send({
          success: true,
          message: "Got the UserID",
          userId: userId,
        });
      }
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({
      success: false,
      message: "unable to get userID",
      error,
    });
  }
});

export const changePasswordCandidate = catchAsyncErrors(async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const userId = req.body.userId;

    // Find the user by userId
    const user = await candidateSignUp.findById(userId);

    // Check if the current password provided matches the stored password
    const isMatch = await bcrypt.compare(currentPassword, user.password);

    if (!isMatch) {
      return res.status(200).send({
        success: false,
        message: "Current password is incorrect",
      });
    }

    // Generate a new hashed password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(newPassword, salt);

    // Update the user's password in the database
    user.password = hashedPassword;
    await user.save();

    res.status(200).json({
      success: true,
      message: "Password changed successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error in changing password",
      error,
    });
  }
});
