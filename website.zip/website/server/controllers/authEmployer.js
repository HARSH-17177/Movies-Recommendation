import employerSignUp from "../mongodb/models/employerRegister.js";
// import ErrorHandler from "../utils/errorhandler.js";
import catchAsyncErrors from "../middleware/catchAsyncErrors.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import OTP from "../mongodb/models/OTP.js";
import otpGenerator from "otp-generator";
import mongoose from "mongoose";
import crypto from "crypto";
import { mailSender } from "../utils/mailSender.js";
mongoose.connection.useDb("test");
//sendOTP
export const sendOTP = catchAsyncErrors(async (req, res, next) => {
  const { email } = req.body;
  //check if employer already exists
  const checkEmployerExist = await employerSignUp.findOne({ email });
  if (checkEmployerExist) {
    return res.status(401).send({
      success: false,
      message: "User already exists",
    });
  }
  //generate  OTP
  var otp = otpGenerator.generate(6, {
    upperCaseAlphabets: false,
    lowerCaseAlphabets: false,
    specialChars: false,
  });
  console.log("OTP generated:", otp);
  //check unique otp or not
  let result = await OTP.findOne({ otp: otp });

  while (result) {
    otp = otpGenerator.generate(6, {
      upperCaseAlphabets: false,
      lowerCaseAlphabets: false,
      specialChars: false,
    });
    result = await OTP.findOne({ otp: otp });
  }
  //save the new OTP to database
  const otpPayload = { email, otp };
  //create an entry in db
  const otpBody = await OTP.create(otpPayload);
  console.log(otpBody);

  //return response successful
  res.status(200).send({
    success: true,
    message: "OTP sent successfully",
    otp,
  });
});
//EMPLOYER SIGNUP
export const registerEmployer = catchAsyncErrors(async (req, res, next) => {
  const { email, password, otp } = req.body;
  if (!email || !password || !otp) {
    return res.status(403).json({
      success: false,
      message: "All fields are required",
    });
  }
  const existingUser = await employerSignUp.findOne({ email });
  if (existingUser) {
    return res.status(400).send({
      success: false,
      message: "User already exists",
    });
  }
  //find most recent OTP stored for the user
  const recentOTP = await OTP.find({ email }).sort({ createdAt: -1 }).limit(1);
  console.log("This is printed in console", recentOTP[0]);
  //validate OTP
  if (recentOTP.length == 0) {
    return res.status(400).send({
      success: false,
      message: "OTP not found",
    });
  } else if (otp !== recentOTP[0].otp) {
    return res.status(400).send({
      success: false,
      message: "OTP not matching",
    });
  }
  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(req.body.password, salt);
  req.body.password = hashedPassword;

  const employerRegistered = await employerSignUp.create(req.body);

  // Generate a JWT token
  const token = jwt.sign(
    { id: employerRegistered._id, role: "Employer" },
    process.env.JWT,
    {
      expiresIn: "1d",
    }
  );

  const userResponse = {
    _id: employerRegistered._id,
    email: employerRegistered.email,
  };

  // Send the response with the token and user details
  res.status(201).json({
    success: true,
    token,
    user: userResponse,
    message: "Signup successful",
  });
});

//EMPLOYER LOGIN
export const loginEmployer = catchAsyncErrors(async (req, res, next) => {
  let user = await employerSignUp.findOne({ email: req.body.email });
  if (!user) {
    return res.status(200).send({
      success: false,
      message: "User Not found",
    });
  }
  const isMatch = await bcrypt.compare(req.body.password, user.password);
  if (!isMatch) {
    return res.status(200).send({
      success: false,
      message: "Invalid Email or Password ",
    });
  }
  const token = jwt.sign({ id: user._id, role: "Employer" }, process.env.JWT, {
    expiresIn: "1d",
  });
  user = user.toObject();
  user.token = token;
  user.password = undefined;
  res.status(200).json({
    success: true,
    message: "Login success",
    token,
    user,
  });
});
// change password
export const changePassword = catchAsyncErrors(async (req, res, next) => {
  const { currentPassword, newPassword } = req.body;

  // Get the logged-in user's ID from the request
  const userId = req.body.user;

  // Find the user by ID
  const user = await employerSignUp.findById(userId);

  // Check if the current password matches
  const isMatch = await bcrypt.compare(currentPassword, user.password);
  if (!isMatch) {
    return res.status(400).json({
      success: false,
      message: "Current password is incorrect",
    });
  }

  // Hash the new password
  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(newPassword, salt);

  // Update the user's password in the database
  await employerSignUp.findByIdAndUpdate(userId, { password: hashedPassword });

  res.status(200).json({
    success: true,
    message: "Password changed successfully",
  });
});

//getting the ID of employer
export const getEmployerID = catchAsyncErrors(async (req, res, next) => {
  try {
    let tok = req.body.token;
    jwt.verify(tok, process.env.JWT, (err, decode) => {
      if (err) {
        console.log("Failed to authorize");
        return;
      } else {
        let userId = decode.id;
        res.status(200).send({
          success: true,
          message: "Got the UserID",
          userId: userId,
        });
      }
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({
      success: false,
      message: "unable to get userID",
      error,
    });
  }
});

// Reset Password Token for Employer
export const resetEmployerPasswordToken = async (req, res) => {
  try {
    let employerEmail = req.body.email;

    const employer = await employerSignUp.findOne({ email: employerEmail });
    if (!employer) {
      return res.status(401).json({
        success: false,
        message: "Your email is not registered with us",
      });
    }

    const token = crypto.randomUUID();
    console.log("The token is:", token);

    const updatedDetails = await employerSignUp.findOneAndUpdate(
      { id: employer._id },
      {
        token: token,
        resetPasswordExpires: Date.now() + 5 * 60 * 1000,
      },
      {
        new: true,
      }
    );

    const url = `http://localhost:3000/update-employer-password/${token}`;
    await mailSender(
      employerEmail,
      "Employer Password Reset Link",
      `password reset link: ${url}`
    );

    return res.status(200).json({
      success: true,
      message:
        "Email sent successfully, please check email and change password",
    });
  } catch (error) {
    console.log(error.message);
    return res.status(500).json({
      success: false,
      message: "Something went wrong while resetting the password",
    });
  }
};

// Reset Password for Employer
export const resetEmployerPassword = async (req, res) => {
  try {
    const { password, confirmPassword, token } = req.body;

    if (password !== confirmPassword) {
      return res.json({
        success: false,
        message: "Password not matching",
      });
    }

    const employerDetails = await employerSignUp.findOne({ token: token });
    if (!employerDetails) {
      res.status(404).json({
        success: false,
        message: "Token is invalid",
      });
    }

    if (employerDetails.resetPasswordExpires < Date.now()) {
      return res.json({
        success: false,
        message: "Token expired",
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const employer = await employerSignUp.findById(employerDetails._id);
    if (!employer) {
      return res.status(404).json({ message: "Employer not found" });
    }

    // Update the password in the EmployerSignUp model
    employer.password = hashedPassword;
    employer.token = null; // Optionally clear the token after the password is reset
    employer.resetPasswordExpires = null; // Optionally clear the resetPasswordExpires after the password is reset
    await employer.save();

    return res.status(200).send({
      success: true,
      message: "Password updated successfully!",
    });
  } catch (error) {
    console.log(error.message);
    res.status(500).send({
      success: false,
      message: "Error occurred when updating Password.",
    });
  }
};
