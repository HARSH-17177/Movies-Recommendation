import employerModel from "../mongodb/models/employerDetails.js";
import jobListing from "../mongodb/models/jobListing.js";
import jobApplication from "../mongodb/models/jobApplication.js";
import ErrorHandler from "../utils/errorhandler.js";
import catchAsyncErrors from "../middleware/catchAsyncErrors.js";
import candidateDetails from "../mongodb/models/candidateDetails.js";
import candidateSignUp from "../mongodb/models/candidateRegister.js";
import generateSignedUrlLogo from "../AWS/logoS3.js";
import mongoose from "mongoose";
mongoose.connection.useDb("test");
//GETTING ALL THE EMPLOYERS ALONG WITH THE DETAILS
export const getEmployerList = catchAsyncErrors(async (req, res) => {
  const EmployerList = await employerModel.find();
  res.status(200).json({
    status: "success",
    EmployerList,
  });
});
//CREATING A EMPLOYER PROFILE
export const createEmployer = catchAsyncErrors(async (req, res, next) => {
  const Employer = await employerModel.create(req.body);

  res.status(201).json({
    success: true,
    Employer,
  });
});
//UPDATING Employer PROFILE
export const updateEmployer = catchAsyncErrors(async (req, res) => {
  let employer = await employerModel.findById(req.params.id);
  if (!employer) {
    return next(new ErrorHandler("Employer Not found", 404));
  }
  employer = await employerModel.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
    useFindAndModify: false,
  });
  res.status(200).json({
    success: true,
    employer,
  });
});
//DELETING Employer PROFILE
export const deleteEmployer = catchAsyncErrors(async (req, res, next) => {
  let foundEmployer = await employerModel.findById(req.params.id);
  if (!foundEmployer) {
    return next(new ErrorHandler("employer Not found", 404));
  }

  await foundEmployer.deleteOne();
  res.status(200).json({
    success: true,
    message: "employer deleted successfully",
  });
});
//GETTING DETAILS OF A PARTICULAR Employer
export const getEmployerDetails = catchAsyncErrors(async (req, res, next) => {
  const foundEmployer = await employerModel.findById(req.params.id);

  if (!foundEmployer) {
    return next(new ErrorHandler("employer Not found", 404));
  }

  res.status(200).json({
    success: true,
    foundEmployer,
  });
});
//Creating a job posting
export const createJobPosting = catchAsyncErrors(async (req, res, next) => {
  const userID = req.body.employer;
  const companyID = await findCompanyName(userID);
  req.body.companyName = companyID;
  const jobPosting = await jobListing.create(req.body);

  res.status(201).json({
    success: true,
    jobPosting,
  });
});
//get the company name id for creating the job posting
async function findCompanyName(username) {
  try {
    // Use findOne to find a document based on the "user" field
    const result = await employerModel.findOne({ user: username });

    // Check if a document was found
    if (result) {
      // Access the "_id" field of the found document
      const userId = result._id;

      console.log("User ID:", userId);
      return userId;
    } else {
      console.log("User not found.");
      return null; // Or handle the case where the user is not found
    }
  } catch (error) {
    console.error("Error:", error.message);
    throw error; // Handle the error appropriately in your application
  }
}

// List of candidates applied for a particular job posting

export const getCandidatesForJobListing = catchAsyncErrors(async (req, res) => {
  const jobId = req.body.jobId;
  const candidates = await jobApplication
    .find({ job_listing: jobId })
    .populate("candidate"); // Populate the candidate details
  if (!candidates) {
    return next(new ErrorHandler("candidate not found", 404));
  }
  res.json(candidates);
});

//All JOBS POSTED BY AN EMPLOYER
export const getPostedJobs = catchAsyncErrors(async (req, res) => {
  const employerId = req.params.employerId;

  const jobListings = await jobListing
    .find({ employer: employerId })
    .select("jobTitle _id");
  if (!jobListings) {
    return next(new ErrorHandler("jobs not found", 404));
  }
  res.json(jobListings);
});

export const getLatestJobApplicants = async (req, res) => {
  const { userId } = req.body; // Assuming userId is passed in the request parameters

  try {
    // Find the latest job posted by the employer
    const latestJob = await jobListing
      .findOne({ employer: userId })
      .sort({ createdAt: -1 })
      .limit(1);

    if (!latestJob) {
      return res
        .status(404)
        .json({ message: "No job found for the specified employer." });
    }

    // Find the job applications for the latest job
    const jobApplications = await jobApplication
      .find({
        job_listing: latestJob._id,
      })
      .sort({ createdAt: -1 })
      .limit(5)
      .populate("candidate", "name email"); // Populate candidate details

    // Extract candidate details
    const applicants = jobApplications.map((application) => ({
      candidate: application.candidate,
      status: application.status,
    }));

    // Combine latestJob and applicants into an array
    const responseArray = [latestJob, ...applicants];

    res.status(200).json(responseArray);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
};
//TO Toggle the shortlisted status of a candidate
export const toggleShortlistStatus = catchAsyncErrors(
  async (req, res, next) => {
    const { jobId, userId } = req.body;

    try {
      // Find the job posting by jobId
      const job = await jobListing.findById(jobId);

      if (!job) {
        return next(new ErrorHandler("Job not found", 404));
      }

      // Find the candidate by userId
      const candidate = await candidateSignUp.findById(userId);

      if (!candidate) {
        return next(new ErrorHandler("Candidate not found", 404));
      }
      // Find the candidate details using the user field in CandidateDetails model
      const candidateDetailsDoc = await candidateDetails.findOne({
        user: userId,
      });

      if (!candidateDetailsDoc) {
        return next(new ErrorHandler("Candidate details not found", 404));
      }

      const index = job.shortlistedCandidates.indexOf(userId);
      if (index !== -1) {
        // If the user is already shortlisted, remove them
        job.shortlistedCandidates.splice(index, 1);
      } else {
        // If the user is not shortlisted, add them
        job.shortlistedCandidates.push(userId);
      }
      // Save the updated job posting
      await job.save();
      // Send the updated job posting with shortlisted candidates back to the client
      res.status(200).json(job);
    } catch (error) {
      console.error(error);
      return next(new ErrorHandler("Internal Server Error", 500));
    }
  }
);

export const getShortlistedCandidates = catchAsyncErrors(
  async (req, res, next) => {
    try {
      const { jobId } = req.body;

      const jobListingDoc = await jobListing.findById(jobId);

      if (!jobListingDoc) {
        console.log("Job listing not found");
        return res.status(404).json({ message: "Job listing not found" });
      }

      const shortlistedCandidatesArray = jobListingDoc.shortlistedCandidates;

      // Find candidate details where the "user" field matches with shortlistedCandidatesArray
      const candidatesDetails = await candidateDetails.find({
        user: { $in: shortlistedCandidatesArray },
      });

      if (!candidatesDetails || candidatesDetails.length === 0) {
        return res
          .status(404)
          .json({ message: "No candidates found with the provided IDs" });
      }
      res.status(200).json({ candidatesDetails });
    } catch (error) {
      console.error(error);
      return next(new ErrorHandler("Internal Server Error", 500));
    }
  }
);
//get the employer statistics
export const getEmployerStats = catchAsyncErrors(async (req, res, next) => {
  const { employerId } = req.body;

  try {
    // Check if employerId is a valid ObjectId
    if (!mongoose.Types.ObjectId.isValid(employerId)) {
      return next(new ErrorHandler("Invalid employerId", 400));
    }

    // Get total number of job postings by the employer
    const totalJobPostings = await jobListing.countDocuments({
      employer: employerId,
    });

    // Get total number of job applications on those job postings
    const totalJobApplications = await jobApplication.countDocuments({
      employer: employerId,
    });

    const jobListings = await jobListing.find({ employer: employerId });

    let totalShortlistedCandidates = 0;

    for (const jobListingDoc of jobListings) {
      if (
        jobListingDoc.shortlistedCandidates &&
        Array.isArray(jobListingDoc.shortlistedCandidates)
      ) {
        totalShortlistedCandidates +=
          jobListingDoc.shortlistedCandidates.length;
      }
    }

    // Get total number of candidates with status "Interview" in the jobs posted by the employer
    const totalInterviewCandidates = await jobApplication.countDocuments({
      employer: employerId,
      status: "Interview",
    });
    const result = {
      totalJobPostings: jobListings.length,
      totalJobApplications,
      totalShortlistedCandidates,
      totalInterviewCandidates,
    };

    res.status(200).json({
      success: true,
      data: result,
    });
  } catch (error) {
    console.error("Error fetching employer stats:", error);
    return next(new ErrorHandler("Error fetching employer stats", 500));
  }
});

//TO Toggle the interview status of a candidate
export const toggleInterviewStatus = catchAsyncErrors(
  async (req, res, next) => {
    const { jobId, userId, status } = req.body;

    try {
      const Id = await candidateDetails.findOne({ user: userId }, "_id");
      // Find the job application by jobId and userId
      const jobApp = await jobApplication.findOne({
        job_listing: jobId,
        candidate: Id,
      });

      if (!jobApp) {
        return next(new ErrorHandler("Job Application not found", 404));
      }

      // Validate the provided status
      const validStatusValues = ["Interview", "Not Shortlisted"];
      if (!validStatusValues.includes(status)) {
        return next(new ErrorHandler("Invalid status value", 400));
      }

      jobApp.status = status;

      await jobApp.save();

      res.status(200).json(jobApp);
    } catch (error) {
      console.error(error);
      return next(new ErrorHandler("Internal Server Error", 500));
    }
  }
);

export const logoController = async (request, response) => {
  const url = await generateSignedUrlLogo(request.body.token);
  response.status(200).json({ url });
};
