import mongoose from "mongoose";

const employerDetailsSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "EmployerSignUp",
      required: [true, "Please login properly first"],
    },
    companyName: {
      type: String,
      required: [true, "Please enter your company's name as per KYC documents"],
    },
    companySize: {
      type: String,
      enum: [
        "Less than 10",
        "10-50",
        "50-200",
        "200-500",
        "500-1000",
        "Greater than 1000",
      ],
      required: [true, "Please select your company size"],
    },
    address: {
      type: String,
      required: [true, "Please enter your company's address"],
    },
    name: {
      type: String,
      required: [true, "Please enter your name"],
    },
    phoneNumber: {
      type: Number,
      required: [true, "Please enter your phone number"],
      unique: true,
    },
    designation: {
      type: String,
      required: [true, "Please enter your designation"],
    },
    brandName: {
      type: String,
      required: [true, "Please enter the brand name"],
    },
    sector: {
      type: String,
      required: [true, "Please enter the sector"],
    },
    logoUrl: {
      type: String,
      required: [true, "Please upload the company logo"],
    },
    token: {
      type: String,
    },
    resetPasswordExpires: {
      type: Date,
    },
    createdAt: { type: Date, default: new Date() },
  },
  { timestamps: true }
);

const employerModel = mongoose.model("EmployerDetails", employerDetailsSchema);

export default employerModel;
