import mongoose from "mongoose";

const jobApplicationSchema = new mongoose.Schema(
  {
    candidate: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "CandidateDetails",
      required: true,
    },
    job_listing: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "JobListing",
      required: true,
    },
    employer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "EmployerSignUp",
      required: true,
    },
    status: { type: String, default: "pending" }, // "pending", "Interview", "rejected", etc.
  },
  { timestamps: true }
);

const jobApplication = mongoose.model("JobApplication", jobApplicationSchema);

export default jobApplication;
