import mongoose from "mongoose";

const jobListingSchema = new mongoose.Schema(
  {
    employer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "EmployerSignUp",
      required: true,
    },
    companyName: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "EmployerDetails",
      required: true,
    },
    jobTitle: {
      type: String,
      required: [true, "Position is required"],
    },
    description: {
      type: String,
      required: [true, "Description is required"],
    },
    workLocation: {
      type: String,
      required: [true, "Work location is required"],
    },
    candidatePreferences: {
      type: String,
    },
    noteJD: {
      type: String,
    },
    workType: {
      type: String,
      required: [true, "Work type is required"],
      enum: ["Job", "Internship"],
    },
    salary: {
      type: String,
      required: [true, "Salary is required"],
    },
    variableSalary: {
      type: String,
    },
    applicationDeadline: {
      type: Date,
    },
    noOfPositions: {
      type: Number,
    },
    shortlistedCandidates: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "CandidateDetails", // Assuming you have a Candidate model
      },
    ],
    perks: {
      type: Array,
    },
  },
  { timestamps: true }
);

const jobListing = mongoose.model("JobListing", jobListingSchema);

export default jobListing;
