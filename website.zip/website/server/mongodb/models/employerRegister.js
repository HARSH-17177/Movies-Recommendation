import mongoose from "mongoose";
import validator from "validator";
const employerSignUpModel = new mongoose.Schema(
  {
    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true,
      validate: validator.isEmail,
    },
    password: {
      type: String,
      required: [true, "Password is required"],
    },
    token: {
      type: String,
    },
    resetPasswordExpires: {
      type: Date,
    },
    createdAt: { type: Date, default: new Date() },
  },
  { timestamps: true }
);

const employerSignUp = mongoose.model("EmployerSignUp", employerSignUpModel);

export default employerSignUp;
