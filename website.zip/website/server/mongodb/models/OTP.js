import mongoose from "mongoose";
import validator from "validator";
import { mailSender } from "../../utils/mailSender.js";
const OTPSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      required: [true, "Email is required"],
      unique: false,
      validate: validator.isEmail,
    },
    otp: {
      type: String,
      required: [true, "OTP is required"],
    },
    createdAt: { type: Date, default: Date.now(), expires: 10 * 60 },
  },
  { timestamps: true }
);

//function to send emails

async function sendVerificationEmail(email, otp) {
  try {
    const mailResponse = await mailSender(
      email,
      "Verification Email from HiremeClub",
      ` <html>
      <body>
        <p>Dear User,</p>
        <p>Thank you for signing up with HiremeClub. To complete your registration, please use the following one-time password (OTP):</p>
        <h2>${otp}</h2>
        <p>This OTP is valid for a limited time, so please use it promptly.</p>
        <p>If you did not sign up for HiremeClub, please ignore this email.</p>
        <p>Best regards,<br/>HiremeClub Team</p>
      </body>
    </html>`
    );
    console.log("Mail sent successfully", mailResponse);
  } catch (error) {
    console.log("Error occured while sending mail:", error.message);
  }
}

OTPSchema.pre("save", async function (next) {
  await sendVerificationEmail(this.email, this.otp);
  next();
});

const OTP = mongoose.model("OTPModel", OTPSchema);

export default OTP;
