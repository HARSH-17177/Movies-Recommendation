import mongoose from "mongoose";

const candidateDetailsSchema = new mongoose.Schema(
  {
    name: { type: String, required: [true, "Please enter your name"] },
    user: { type: mongoose.Schema.Types.ObjectId, required: true },
    email: {
      type: String,
      required: [true, "Please enter your email"],
    },
    dob: { type: String, required: [true, "Please enter your Date of Birth"] },
    college: {
      type: String,
      required: [true, "Please enter your college name"],
    },
    collegeyear: {
      type: Number,
      required: [true, "Please enter your year of passing"],
    },
    collegecgpa: { type: Number },
    collegedegree: { type: String },
    school: {
      type: String,
      required: [true, "Please enter your school name"],
    },
    schoolyear: {
      type: Number,
      required: [true, "Please enter your year of passing (school)"],
    },
    schoolcgpa: { type: Number },
    schooldegree: { type: String },
    mobno: {
      type: Number,
      // required: [true, "Please enter your phone number"],
    },
    exe1: { type: String },
    exedes1: { type: String },
    exe2: { type: String },
    exedes2: { type: String },
    project: { type: String },
    projectdes: { type: String },
    skills: { type: Array },
    achievement1: { type: String },
    achievement1des: { type: String },
    achievement2: { type: String },
    achievement2des: { type: String },
    res: { type: String },
    resdes: { type: String },
    certificate: { type: String },
    certificatedes: { type: String },
    wishlist: [{ type: mongoose.Schema.Types.ObjectId, ref: "JobListing" }],
    scoreExcel: { type: Number },
    scoreReasoning: { type: Number },
    scoreAnalytical: { type: Number },
    createdAt: { type: Date, default: new Date() },
  },
  { timestamps: true }
);

const candidateModel = mongoose.model(
  "CandidateDetails",
  candidateDetailsSchema
);

export default candidateModel;
