import aws from "aws-sdk";
import dotenv from "dotenv";
import JWT from "jsonwebtoken";
dotenv.config();

const region = process.env.AWS_REGION_RESUME;
const bucketName = process.env.S3_BUCKET_NAME_RESUME;
const accessKeyId = process.env.AWS_ACCESS_KEY_ID;
const secretAccessKey = process.env.AWS_SECRET_ACCESS_KEY;
let userId;
const s3 = new aws.S3({
  region,
  accessKeyId,
  secretAccessKey,
  signatureVersion: "v4",
});

const generateSignedUrlResume = async (tok) => {
  try {
    JWT.verify(tok, process.env.JWT_SECRET, (err, decode) => {
      if (err) {
        console.log("Failed");
        return;
      } else {
        userId = decode.id;
      }
    });
  } catch (error) {
    console.log(error);
  }

  const params = {
    Bucket: bucketName,
    Key: userId + ".pdf",
    Expires: 60,
  };

  const signedUrl = await s3.getSignedUrlPromise("putObject", params);
  return signedUrl;
};

export default generateSignedUrlResume;
