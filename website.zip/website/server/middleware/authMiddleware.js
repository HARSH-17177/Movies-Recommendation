import JWT from "jsonwebtoken";

export const auth = async (req, res, next) => {
  try {
    const token = req.body.token || req.cookies.token;
    if (!token) {
      return res
        .status(401)
        .send({ success: false, message: "No token provided." });
    }
    JWT.verify(token, process.env.JWT_SECRET, (err, decode) => {
      if (err) {
        return res.status(401).send({
          success: false,
          message: "Auth Failed",
        });
      } else {
        req.body.userId = decode.id;
        next();
      }
    });
  } catch (error) {
    console.log(error);
    return res.status(401).send({
      success: false,
      error,
      message: "Auth failed",
    });
  }
};

//isCandidate
export const isCandidate = async (req, res, next) => {
  try {
    if (req.body.role !== "Candidate") {
      return res.status(401).send({
        success: false,
        message: "this is a protected route for candidates only",
      });
    }
    next();
  } catch (error) {
    return res.status(500).send({
      success: false,
      message: "User role cannot be verified",
    });
  }
};

//isEmployer
export const isEmployer = async (req, res, next) => {
  try {
    if (req.body.role !== "Employer") {
      return res.status(401).send({
        success: false,
        message: "this is a protected route for Employer only",
      });
    }
    next();
  } catch (error) {
    return res.status(500).send({
      success: false,
      message: "User role cannot be verified",
    });
  }
};
