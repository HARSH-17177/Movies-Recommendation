# website
Transforming hiring with AI-powered talent matching, delivering pre-screened candidates in just 24 hours
How to Run:
1. Split Terminal
2. Cd Client
3. NPM i
4. NPM Start
5. Cd Server
6. NPM i
7. NPM Start

I have added all the pages to Routes, If you want to acces "Candidate Side" then:-
1. Login First
2. Enter credentials as:-
username:- kuber@gmail.com
passwords:- testing

4. For Employer Side:-
Enter Credentials as:-
username :- test@gmail.com
password:- testing


# if want to run this using docker simply 
* install docker-compose in your system
* run docker-compose up and you can view complete working website on it on localhost:3000
* to stop run docker-comopse down on terminal
