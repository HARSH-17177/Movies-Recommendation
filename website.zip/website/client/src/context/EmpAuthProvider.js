import React, { createContext, useContext, useEffect, useState } from 'react';
import { getEmployerID } from '../service/api';

const EmpAuthContext = createContext();

export const EmpAuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const token = getCookie();

    if (token) {
      // Fetch user details using the token
      getEmployerID(token)
        .then((response) => {
   
            console.log(response.message); // Log the message if needed
            setUser({ userId: response.userId });
         
        })
        .catch((error) => {
          console.error('Error fetching user details:', error);
          // Handle error, set user to null, or perform logout actions
          setUser(null);
        });
    }
  }, []);

  const getCookie = () => {
    const cookie = document.cookie.split('; ').find((row) => row.startsWith('token='));

    if (cookie) {
      const cookieValue = cookie.split('=')[1];
      return cookieValue;
    }

    return null;
  };

  const isEmpLoggedIn = Boolean(user);
  const isLoggedOut = !user;

  return (
    <EmpAuthContext.Provider value={{ isEmpLoggedIn, isLoggedOut, userData: user }}>
      {children}
    </EmpAuthContext.Provider>
  );
};

export const useAuthEmp = () => {
  const context = useContext(EmpAuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
