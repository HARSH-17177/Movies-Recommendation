import React from 'react';
import { useAuth } from './AuthProvider';
import { useAuthEmp } from './EmpAuthProvider';

const AuthWrapper = ({ candidateComponent, employerComponent, fallbackComponent }) => {
  const { isLoggedIn } = useAuth();
  const { isEmpLoggedIn } = useAuthEmp();

  if (isLoggedIn) {
    return candidateComponent;
  } else if (isEmpLoggedIn) {
    return employerComponent;
  } else {
    return fallbackComponent;
  }
};

export default AuthWrapper;
