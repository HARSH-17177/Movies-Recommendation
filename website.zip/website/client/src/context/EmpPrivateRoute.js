import React,{ useState, useEffect } from "react";
import { useAuthEmp } from "./EmpAuthProvider";
import { Outlet } from "react-router-dom";
import MagnifyingGlassComponent from '../Loader/MagnifyingGlass'

function EmpPrivateRoute() {
    const { isEmpLoggedIn } = useAuthEmp();
    
  return isEmpLoggedIn ? <Outlet/> : <MagnifyingGlassComponent destination="/emp-login"/>;
}

export default EmpPrivateRoute