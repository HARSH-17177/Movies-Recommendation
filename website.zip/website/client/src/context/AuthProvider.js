import React, { createContext, useContext, useEffect, useState } from 'react';
import { getUserID } from '../service/api';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [loading, setLoading] = useState(true);
  const [user,setUser] = useState(null);

  useEffect(() => {
    const token = getCookie();

   
    if (token) {
      // Fetch user details using the token
      getUserID(token)
        .then((response) => {
   
            console.log(response.message); // Log the message if needed
            setUser({ userId: response.userId });
         
        })
        .catch((error) => {
          console.error('Error fetching user details:', error);
          // Handle error, set user to null, or perform logout actions
          setUser(null);
        });
    }

    setLoading(false);
  }, []);

  const getCookie = () => {
    const cookie = document.cookie.split('; ').find((row) => row.startsWith('token='));

    if (cookie) {
      const cookieValue = cookie.split('=')[1];
      return cookieValue;
    }

    return null;
  };

  const isLoggedIn = Boolean(user);
  const isLoggedOut = !user;

  return (
    <AuthContext.Provider value={{ userData: user, isLoggedIn, isLoggedOut, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
