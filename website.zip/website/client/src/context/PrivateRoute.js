import React,{ useState, useEffect } from "react";
import { useAuth } from "./AuthProvider";
import { Outlet } from "react-router-dom";
import MagnifyingGlassComponent from '../Loader/MagnifyingGlass';

function PrivateRoute() {
    const { isLoggedIn } = useAuth();
    console.log(isLoggedIn);
    
  return isLoggedIn ? <Outlet/> : <MagnifyingGlassComponent destination="/login"/>;
}

export default PrivateRoute