import axios from "axios";

const headers = {
  "Content-Type": "multipart/form-data",
};

const API_URI = "http://localhost:8080/api/v1";

const EC2_confidence =
  "http://ec2-54-213-235-176.us-west-2.compute.amazonaws.com:8080/confidence/";
const resumeJSON =
  "http://ec2-35-160-183-251.us-west-2.compute.amazonaws.com:8080/resume";

const stage2RoleBased =
  "http://ec2-35-87-21-238.us-west-2.compute.amazonaws.com:8080/role_ques/";

const stage2Excel =
  "http://ec2-35-87-21-238.us-west-2.compute.amazonaws.com:8080/excel/";

const stage2Analytical =
  "http://ec2-35-87-21-238.us-west-2.compute.amazonaws.com:8080/analytical/";

const stage2Reasoning =
  "http://ec2-35-87-21-238.us-west-2.compute.amazonaws.com:8080/reasoning/";

const stage2CreativeIdea =
  "http://ec2-35-87-21-238.us-west-2.compute.amazonaws.com:8080/creative/";

const stage2RoleScore =
  "http://ec2-35-87-21-238.us-west-2.compute.amazonaws.com:8080/role_score/";

const stage2CreativeScore =
  "http://ec2-35-87-21-238.us-west-2.compute.amazonaws.com:8080/creative_score/";

const resumeScore =
  "http://ec2-35-160-183-251.us-west-2.compute.amazonaws.com:8080/score/";

const stage3Fluency =
  "http://ec2-34-221-91-133.us-west-2.compute.amazonaws.com:8000/s3";

const stage3Question =
  "http://ec2-35-87-21-238.us-west-2.compute.amazonaws.com:8080/situation/";

//getting the URL for uploading to AWS
export const getSignedUrl = async (data, tok) => {
  try {
    console.log(data);
    let fname = {
      name: data,
      token: tok,
    };

    const response = await axios.post(`${API_URI}/image-url`, fname, {
      headers: { "Content-Type": "application/json", withCredentials: true },
    });

    return response.data;
  } catch (error) {
    console.log("Error while calling the API ", error.message);
    return error.response;
  }
};

//uploading the video to the URL generated
export const uploadFile = async (url, file) => {
  try {
    const response = await axios.put(url, file, { headers: headers });
    console.log("uploaded successfully");
    return response.data;
  } catch (error) {
    console.log("Error while calling the API ", error.message);
    return error.response;
  }
};
//for getting the Stage 3 confidence
export const getConfidence = async (token) => {
  try {
    const user = await getUserID(token);
    const response = await axios.post(
      `${EC2_confidence}` + `${user}`,
      {
        file_name: `${user}/stage_3.webm`,
      },
      {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "http://localhost:3000",
        },
      }
    );
    console.log(response.data);
  } catch (error) {
    console.log("Error while getting confidence ", error.message);
    return error.response;
  }
};
//for getting the details from the resume in JSON format
export const getResumeJSON = async (tok) => {
  try {
    const user = await getUserID(tok);
    const response = await axios.post(
      resumeJSON,
      {
        file_name: `${user}.pdf`,
      },
      {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "http://localhost:3000",
        },
      }
    );
    console.log("mLApi = ", response.data);
    return response.data;
  } catch (error) {
    console.log("Error while getting resume details ", error.message);
    return error.response;
  }
};
//for getting the stage 2 role based questions
export const getStage2Questions = async (tok) => {
  try {
    const user = await getUserID(tok);
    const response = await axios.get(`${stage2RoleBased}` + `${user}/sales`, {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "http://localhost:3000",
      },
    });
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.log("Error while getting the stage 2 questions ", error.message);
    return error.response;
  }
};

//for getting the stage 2 Excel questions
export const getStage2Excel = async (tok) => {
  try {
    const user = await getUserID(tok);
    const response = await axios.get(`${stage2Excel}` + `${user}`, {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "http://localhost:3000",
      },
    });
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.log("Error while getting the stage 2 questions ", error.message);
    return error.response;
  }
};

//for getting the stage 2 Analytical questions
export const getStage2Analytical = async (tok) => {
  try {
    const user = await getUserID(tok);
    const response = await axios.get(`${stage2Analytical}` + `${user}`, {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "http://localhost:3000",
      },
    });
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.log("Error while getting the stage 2 questions ", error.message);
    return error.response;
  }
};

//for getting the stage 2 Reasoning questions
export const getStage2Reasoning = async (tok) => {
  try {
    const user = await getUserID(tok);
    const response = await axios.get(`${stage2Reasoning}` + `${user}`, {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "http://localhost:3000",
      },
    });
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.log("Error while getting the stage 2 questions ", error.message);
    return error.response;
  }
};

//for getting the stage 2 Reasoning questions
export const getStage2CreativeIdea = async (tok) => {
  try {
    const user = await getUserID(tok);
    const response = await axios.get(`${stage2CreativeIdea}` + `${user}`, {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "http://localhost:3000",
      },
    });
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.log("Error while getting the stage 2 questions ", error.message);
    return error.response;
  }
};

//for getting the stage 3 sales pitch
export const getStage3Question = async (token) => {
  try {
    const user = await getUserID(token);
    const response = await axios.get(`${stage3Question}` + `${user}`, {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "http://localhost:3000",
      },
    });
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.log("Error while getting question ", error.message);
    return error.response;
  }
};
//to get the fluency for the stage 3 video
export const getStage3Fluency = async (token) => {
  try {
    const user = await getUserID(token);
    const response = await axios.post(`${stage3Fluency}/${user}`, {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "http://localhost:3000",
      },
    });
    console.log(response.data.prediction);
    return response.data.prediction;
  } catch (error) {
    console.log("Error while getting fluency ", error.message);
    return error.response;
  }
};

//for storing the stage 2 Creative Video score in mongoDB
export const storeStage2CreativeVideoScore = async (tok) => {
  try {
    const user = await getUserID(tok);
    const response = await axios.get(`${stage2CreativeScore}` + `${user}`, {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "http://localhost:3000",
      },
    });
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.log("Error while storing score  ", error.message);
    return error.response;
  }
};

//for storing the stage 2 Role based Video score in mongoDB
export const storeStage2RoleVideoScore = async (tok) => {
  try {
    const user = await getUserID(tok);
    const response = await axios.get(`${stage2RoleScore}` + `${user}`, {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "http://localhost:3000",
      },
    });
    console.log(response.data);
    return response.data;
  } catch (error) {
    console.log("Error while storing score  ", error.message);
    return error.response;
  }
};
//for getting the resume score from the JSON file
export const getResumeScore = async (data, token) => {
  try {
    const user = await getUserID(token);
    const response = await axios.post(
      `${resumeScore}` + `${user}`,
      {
        ...data,
      },
      { headers: { "Content-Type": "application/json" } }
    );
    console.log(response.data);
  } catch (error) {
    console.log("Error while getting resume score ", error.message);
    return error.response;
  }
};
//get the userID from the JWT token
export const getUserID = async (token) => {
  try {
    const response = await axios.post(
      `${API_URI}/UserID`,
      {
        token: token,
      },
      {
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "http://localhost:3000",
        },
      }
    );
    console.log(response.data.userId);
    return response.data.userId;
  } catch (error) {
    console.log(error);
  }
};
