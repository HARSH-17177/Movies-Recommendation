import { TopNavigation } from "../../components/NavBar/TopNavigation";
import SideNavigation from "../../components/NavBar/SideNavigation";
import "./dashboard.css";
import Employer from "../../components/dashboard/Employer";
import Sidebar from "../../components/NavBar/EmployerSidebar";
import { useEffect, useState } from "react";
import Candidates from "../../components/dashboard/Candidates";
import Interview from "../../components/dashboard/Interview";
import PostJob from "../../components/dashboard/PostJob";
import Settings from "../../components/dashboard/Settings";
import { Footer } from "../../components/Footer";
import { useNavigate, Routes, Route } from "react-router-dom";
import ComingSoon from "../../components/ComingSoon";

const EmployerDashboard = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const token = getCookie();
  }, []);

  const getCookie = () => {
    const cookieValue = document.cookie
      .split("; ")
      .find((row) => row.startsWith("token="));
    if (cookieValue) {
      return cookieValue.split("=")[1];
    } else {
      return null;
    }
  };

  return (
    <>
      <div className="w-screen contain bg-gray-100 ">
        <div className="topNav ">
          <TopNavigation
            isSticky={false}
            showAvatar={true}
            showDashboard={true}
            handleLogout={() => navigate("/emp-login")}
            handleDashboard={() => navigate("/emp-dashboard")}
            dashboardPath="/emp-dashboard"
          />
        </div>
        <div className="outer-container lg:grid  lg:grid-cols-5 lg:grid-rows-1 md:grid  md:grid-cols-4">
          <div className="sideNav md:grid md:col-start-1 md:row-start-1 ">
            <Sidebar />
          </div>
          <div className="inner-container row-start-1 col-start-2 lg:col-span-5 md:col-span-5 mr-10">
            <Routes>
            <Route path="" element={<Employer />} />
            <Route path="postjob" element={<PostJob />} />
            <Route path="comingsoon" element={<ComingSoon />} />
            <Route path="interview" element={<Interview />} />
            <Route path="candidates" element={<Candidates />} />
            <Route path="settings" element={<Settings />} />
          </Routes>
          </div>
        </div>
      </div>
      <div className="bg-gray-100">
      <Footer showBookingSlot={true} />
      </div>
    </>
  );
};

export default EmployerDashboard;
