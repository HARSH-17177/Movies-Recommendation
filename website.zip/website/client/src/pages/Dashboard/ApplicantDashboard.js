import { TopNavigation } from "../../components/NavBar/TopNavigation";
import SideNavigation from "../../components/NavBar/SideNavigation";
import "./dashboard.css";
import { Routes, Route } from "react-router-dom";
import Applicant from "../../components/dashboard/Applicant";
import Sidebar from "../../components/NavBar/CandidateSidebar";
import { getAllJobApplications } from "../../service/api";
import { useEffect } from "react";
import Wishlist from "../../components/dashboard/Wishlist";
import ComingSoon from "../../components/ComingSoon";
import Profile from "../../components/dashboard/Profile";
import { Footer } from "../../components/Footer";
import { Link, Navigate, useNavigate } from "react-router-dom";
import Interview from "../../components/dashboard/Interview";

const ApplicantDashboard = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const token = getCookie();
  }, []);

  const getCookie = () => {
    const cookie = document.cookie
      .split("; ")
      .find((row) => row.startsWith("token="));

    if (cookie) {
      const cookieValue = cookie.split("=")[1];
      return cookieValue;
    }

    return null;
  };

  return (
    <div className="bg-gray-100">
      <div className="max-w-full contain bg-gray-100">
        <div className="topNav ">
          <TopNavigation
            isSticky={false}
            showAvatar={true}
            showDashboard={true}
            handleLogout={() => navigate("/login")}
            dashboardPath="/dashboard"
          />
        </div>
        <div className="outer-container lg:grid  lg:grid-cols-5 lg:grid-rows-1 md:grid  md:grid-cols-4  ">
          <div className="sideNav md:grid md:col-start-1 md:row-start-1 ">
            <Sidebar />
          </div>
          <div className="inner-container rounded-xl row-start-1 col-start-2 lg:col-span-5 md:col-span-5 mr-10">
            <Routes>
              <Route path="" element={<Applicant />} />
              <Route path="interview" element={<ComingSoon />} />
              <Route path="inbox" element={<ComingSoon />} />
              <Route path="wishlist" element={<Wishlist />} />
              <Route path="profile" element={<Profile />} />
            </Routes>
          </div>
        </div>
      </div>
      <div className="bg-gray-100">
        <Footer />
      </div>
    </div>
  );
};

export default ApplicantDashboard;
