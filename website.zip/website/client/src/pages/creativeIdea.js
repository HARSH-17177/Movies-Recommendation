import React, { useState, useRef, useEffect } from "react";
import {
  uploadFile,
  getSignedUrl,
  getStage2CreativeIdea,
  storeStage2CreativeVideoScore,
} from "../service/mlAPI";
import problem from "../images/problem.png";
import CountdownTimer from "../components/portal/CountdownTimer";
import { TopNavigation } from "../components/NavBar/TopNavigation";
import TabSwitch from "../components/portal/TabSwitch";
import { useNavigate, useLocation } from "react-router-dom";
const mimeType = 'video/webm; codecs="opus,vp8"';

export default function CreativeIdea() {
  const location = useLocation();
  const videoRef = useRef(null);
  const liveVideoFeed = useRef(null);
  const mediaRecorder = useRef(null);
  const [url, setUrl] = useState("");
  const localVideoChunksRef = useRef([]);
  const [permission, setPermission] = useState(false);
  const [recordingStatus, setRecordingStatus] = useState("inactive");
  const streamRef = useRef(null);
  const [recordedVideo, setRecordedVideo] = useState(null);
  const [videoChunks, setVideoChunks] = useState([]);
  const [videoBlob, setVideoBlob] = useState(null);
  const timerIdRef = useRef(null);
  const questionNumberRef = useRef(0);
  const questionsArray = useRef([]);
  const randomQuestion = useRef(null);
  const navigate = useNavigate();
  const startTimer = () => {
    // Clear any existing timer
    if (timerIdRef.current) {
      clearTimeout(timerIdRef.current);
    }

    // Start a new timer and store its ID
    const newTimerId = setTimeout(() => {
      console.log("Timer expired!");
      handleNextQuestion();
    }, 10000);

    timerIdRef.current = newTimerId;
  };

  const resetTimer = () => {
    // Clear the timer if it exists
    if (timerIdRef.current) {
      clearTimeout(timerIdRef.current);
      timerIdRef.current = null; // Reset the timer ID
    }
  };

  const fetchData = async () => {
    await getCameraPermission();
    console.log("after camera permission");
    // Retrieve the state from the previous page
    const state = location.state;
    console.log(state);

    // If questionsArray is not present, fetch questions using the API
    if (!state || !state.questionsArray) {
      console.log("no state found");
      const cookieVal = getCookie();
      await getQuestionsFromOpenAI(cookieVal);
    } else {
      console.log("State found");
      // Use questionsArray from the previous page
      questionsArray.current = state.questionsArray;
      await startTest();
    }
  };

  useEffect(() => {
    fetchData();
  }, [location]);

  //when we get video then upload it to aws
  const AWSUpload = async (Blob, url) => {
    console.log("upload function start", Blob.type);
    if (Blob) {
      await uploadFile(url, Blob);
      setUrl(url.split("?")[0]);
      console.log("upload function end");
    }
  };
  const getNextQuestion = async () => {
    if (questionsArray.current.length === 0) {
      console.log("No questions available.");
      return;
    }
    console.log(questionsArray);
    // Get and remove the first question from the array
    const randomQues = questionsArray.current.shift();
    randomQuestion.current = randomQues;
    questionNumberRef.current += 1;
    await startRecording();
  };

  const handleNextQuestion = async () => {
    if (questionNumberRef.current >= 2) {
      endRecording();
    } else {
      stopRecording();
    }
  };
  const getQuestionsFromOpenAI = async (data) => {
    try {
      let q5 = await getStage2CreativeIdea(data);
      questionsArray.current = [q5.ques1, q5.ques2];
      console.log(questionsArray.current);
      startTest();
    } catch (error) {
      console.log("Error getting questions from OpenAI", error.message);
    }
  };

  const getCameraPermission = async () => {
    setRecordedVideo(null);

    if ("MediaRecorder" in window) {
      try {
        const videoConstraints = {
          audio: false,
          video: true,
        };
        const audioConstraints = { audio: true };

        const audioStream = await navigator.mediaDevices.getUserMedia(
          audioConstraints
        );
        const videoStream = await navigator.mediaDevices.getUserMedia(
          videoConstraints
        );

        setPermission(true);

        const combinedStream = new MediaStream([
          ...videoStream.getVideoTracks(),
          ...audioStream.getAudioTracks(),
        ]);

        streamRef.current = combinedStream;

        liveVideoFeed.current.srcObject = videoStream;
      } catch (err) {
        console.error("Error accessing camera:", err.message);
        alert("Error accessing camera: " + err.message);
      }
    } else {
      alert("The MediaRecorder API is not supported in your browser.");
    }
  };

  const startRecording = async () => {
    resetTimer();
    setRecordingStatus("recording");

    const media = new MediaRecorder(streamRef.current, { mimeType });
    mediaRecorder.current = media;
    mediaRecorder.current.start();

    mediaRecorder.current.ondataavailable = (event) => {
      if (typeof event.data === "undefined") return;
      if (event.data.size === 0) return;
      localVideoChunksRef.current = [];
      localVideoChunksRef.current.push(event.data);
    };

    setVideoChunks(localVideoChunksRef.current);
    startTimer();
  };

  const startTest = async () => {
    setRecordingStatus("recording");

    const media = new MediaRecorder(streamRef.current, { mimeType });
    mediaRecorder.current = media;
    mediaRecorder.current.start();

    mediaRecorder.current.ondataavailable = (event) => {
      if (typeof event.data === "undefined") return;
      if (event.data.size === 0) return;
      localVideoChunksRef.current = [];
      localVideoChunksRef.current.push(event.data);
    };

    setVideoChunks(localVideoChunksRef.current);
    if (questionsArray.current.length === 0) {
      console.log("No more questions available.");
      return;
    }
    console.log(questionsArray);
    // Get and remove the first question from the array
    const randomQues = questionsArray.current.shift();
    randomQuestion.current = randomQues;
    questionNumberRef.current += 1;
    console.log("Stage_2_", questionNumberRef.current);
    startTimer();
  };

  const stopRecording = () => {
    setPermission(false);
    setRecordingStatus("inactive");
    mediaRecorder.current.stop();

    mediaRecorder.current.onstop = async () => {
      const vidBlob = new Blob(localVideoChunksRef.current, {
        type: mimeType,
      });
      const videoUrl = URL.createObjectURL(vidBlob);
      setRecordedVideo(videoUrl);
      setVideoBlob(vidBlob);
      setVideoChunks([]);
      let videoNum = "creative-video" + questionNumberRef.current;
      let cookieVal = getCookie();
      const response = await getSignedUrl(videoNum, cookieVal);
      await getNextQuestion();
      await AWSUpload(vidBlob, response.url);
      console.log("After the Upload function in Stop recording");
    };
  };
  const getCookie = () => {
    const cookieValue = document.cookie
      .split("; ")
      .find((row) => row.startsWith("token="))
      .split("=")[1];
    return cookieValue;
  };

  const endRecording = () => {
    setPermission(false);
    setRecordingStatus("inactive");
    mediaRecorder.current.stop();
    resetTimer();
    mediaRecorder.current.onstop = async () => {
      const vidBlob = new Blob(localVideoChunksRef.current, {
        type: mimeType,
      });
      const videoUrl = URL.createObjectURL(vidBlob);
      setRecordedVideo(videoUrl);
      setVideoBlob(vidBlob);
      setVideoChunks([]);
      let videoNum = "creative-video" + questionNumberRef.current;
      const response = await getSignedUrl(videoNum);
      await AWSUpload(vidBlob, response.url);
      let cookieVal = getCookie();
      storeStage2CreativeVideoScore(cookieVal);
      navigate("/insstage3");
    };
  };
  return (
    <div className="bg-gray-50">
      <TopNavigation
        showAvatar={true}
        handleLogout={() => navigate("/login")}
      />
      {/* <TabSwitch /> */}
      <div className="flex flex-col items-center justify-center bg-gray-50 min-h-fit min-w-full">
        <img
          src={problem}
          alt="Question vector Image"
          className="max-w-min max-h-min ml-8 mt-2"
        />
        <CountdownTimer initialTime={80} className="max-h-fit" />

        <div className="bg-white rounded-3xl shadow-2xl p-4 m-10 mt-2">
          <h3 className="text-black p-2 m-2">
            {randomQuestion ? (
              <div>
                <p>{randomQuestion.current}</p>
              </div>
            ) : (
              <p>Loading random question...</p>
            )}
          </h3>
        </div>
        <div className="w-72 h-48 sm:w-3/5 sm:h-auto md:aspect-w-16/9 sm:aspect-h-9/16 bg-gray-500">
          <video ref={liveVideoFeed} autoPlay className="live-player"></video>
        </div>

        <div className="mt-4">
          {recordingStatus === "recording" ? (
            <>
              <button
                onClick={endRecording}
                className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
              >
                End Test
              </button>

              <button
                onClick={handleNextQuestion}
                className={`${
                  questionNumberRef.current === 2 ? "hidden" : ""
                } bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mr-2`}
              >
                Next Question
              </button>
            </>
          ) : null}
        </div>
      </div>
      <h3>Video rendered using AWS link</h3>

      {videoBlob && (
        <video width="400" height="200" controls src={url}>
          Browser not supported
        </video>
      )}
    </div>
  );
}
