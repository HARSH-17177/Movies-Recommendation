import React from 'react'
import { Header } from '../components/employerLanding/Header'
import Comparison from '../components/employerLanding/Comparison'
import { Categories } from '../components/portal/Categories'
import Parameters from '../components/employerLanding/Parameters'
import { Footer } from '../components/Footer'
import EmployerNavbar from '../components/NavBar/EmployerNavbar'


export default function EmployerLanding() {
  return (
    <div  className="bg-gray-100">
    <EmployerNavbar/>
    <Header/>
    <Comparison/>
    <Categories/>
    <Parameters />
    <Footer showBookingSlot={true}/>
    </div>
  )
}
