import React, { useEffect, useRef, useState } from "react";
import { Footer } from "../components/Footer";
import TopNavigation from "../components/NavBar/TopNavigation";
import { uploadFile } from "../service/mlAPI";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import { getEmployerID } from "../service/api";
import { getSignedUrlLogo } from "../service/api";
import { useNavigate } from "react-router-dom";

export default function ResumeData() {
  const API_URI = "http://localhost:8080/api/v1";
  const [url, setUrl] = useState("");
  const navigate = useNavigate();
  const [file, setFile] = useState("");
  const [form, setForm] = useState({
    logoUrl: "",
    name: "",
    designation: "",
    phoneNumber: "",
    brandName: "",
    sector: "",
    companyName: "",
    companySize: "",
    address: "",
  });
  useEffect(() => {
    const getData = async () => {
      let cookieVal = getCookie();
      const response = await getSignedUrlLogo(cookieVal);
      setUrl(response.url);
      console.log(response.url);
    };
    getData();
  }, []);

  useEffect(() => {
    const getData = async () => {
      try {
        await uploadFile(url, file);
      } catch (error) {
        console.error("Error uploading file:", error);
      }
    };
    file && getData();
  }, [file]);
  const handleImageChange = (e) => {
    const selectedFile = e.target.files[0];
    if (
      selectedFile &&
      (selectedFile.type === "image/png" || selectedFile.type === "image/jpeg")
    ) {
      setFile(selectedFile);
      setForm({ ...form, logoUrl: url });
    } else {
      alert("Please select a Image file.");
      e.target.value = null; // Clear the file input
    }
  };
  const getCookie = () => {
    const cookieValue = document.cookie
      .split("; ")
      .find((row) => row.startsWith("token="))
      .split("=")[1];
    return cookieValue;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    await sendEmployerDetails();
    toast.success("Registered Successfully!");
    navigate('/emp-dashboard');
  };

  //to send the employer details to the backend
  const sendEmployerDetails = async () => {
    try {
      let cookieVal = getCookie();
      let user = await getEmployerID(cookieVal);
      console.log(form);
      const response = await axios.post(
        `${API_URI}/Employer/new`,
        {
          ...form,
          user: user,
        },
        {
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "http://localhost:3000",
          },
        }
      );
      return response.data;
    } catch (error) {
      console.log(error.response.data);
    }
  };

  return (
    <div>
      <div className="bg-gray-50">
      <TopNavigation
            isSticky={false}
            showAvatar={true}
            handleLogout={() => navigate("/emp-login")}
          />
        <div className="resume-data">
          <div className="bg-gray-50 min-h-screen py-8 lg:px-36">
            <div className="container mx-auto sm:p-8">
              <h2 className="text-3xl font-semibold mb-4 text-center">
                Employer's Detail
              </h2>
              <form onSubmit={handleSubmit}>
                <div className="border mb-3 bg-white rounded-lg lg:p-5 sm:p-8">
                  {/*Basic Candnameate's Details */}
                  <div className="mb-6 flex space-x-4">
                    <div className="w-full">
                      <label
                        htmlFor="name"
                        className="block mb-2 text-sm font-medium "
                      >
                        Name
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={form.name}
                        onChange={(e) =>
                          setForm({ ...form, name: e.target.value })
                        }
                        className="w-full bg-white-100 border border-gray-300 text-gray-700 text-sm rounded-lg p-2 "
                      />
                    </div>

                    <div className="w-full">
                      <label
                        htmlFor="dob"
                        className="block mb-2 text-sm font-medium "
                      >
                        Designation
                      </label>
                      <input
                        type="text"
                        value={form.designation}
                        onChange={(e) =>
                          setForm({ ...form, designation: e.target.value })
                        }
                        name="designation"
                        className="w-full bg-white-100 border border-gray-300 text-gray-700 text-sm rounded-lg p-2"
                      />
                    </div>
                  </div>

                  {/*Contact Information */}
                  <div className="mb-6  flex space-x-4">
                    <div className="w-full">
                      <label
                        htmlFor="phone"
                        className="block mb-2 text-sm font-medium"
                      >
                        Mobile Number
                      </label>
                      <input
                        value={form.phoneNumber}
                        onChange={(e) =>
                          setForm({ ...form, phoneNumber: e.target.value })
                        }
                        type="tel"
                        name="phoneNumber"
                        className="w-full bg-white-100 border border-gray-300 text-gray-700 text-sm rounded-lg p-2"
                      />
                    </div>

                    <div className="w-full">
                      <label
                        htmlFor="brandName"
                        className="block mb-2 text-sm font-medium "
                      >
                        Brand Name
                      </label>
                      <input
                        value={form.brandName}
                        placeholder="Ex:- Hirepreneurs Technologies Pvt. Ltd."
                        onChange={(e) =>
                          setForm({ ...form, brandName: e.target.value })
                        }
                        type="text"
                        name="brandName"
                        className="w-full bg-white-100 border border-gray-300 text-gray-700 text-sm rounded-lg p-2"
                      />
                    </div>
                  </div>
                  <div className="mb-6  flex space-x-4">
                    <div className="w-full">
                      <label
                        htmlFor="sector"
                        className="block mb-2 text-sm font-medium"
                      >
                        Sector
                      </label>
                      <input
                        type="text"
                        value={form.sector}
                        onChange={(e) =>
                          setForm({ ...form, sector: e.target.value })
                        }
                        name="sector"
                        className="w-full bg-white-100 border border-gray-300 text-gray-700 text-sm rounded-lg p-2"
                      />
                    </div>

                    <div className="w-full">
                      <label
                        htmlFor="companyName"
                        className="block mb-2 text-sm font-medium "
                      >
                        Company Name
                      </label>
                      <input
                        type="text"
                        value={form.companyName}
                        onChange={(e) =>
                          setForm({ ...form, companyName: e.target.value })
                        }
                        name="companyName"
                        className="w-full bg-white-100 border border-gray-300 text-gray-700 text-sm rounded-lg p-2"
                      />
                    </div>
                  </div>
                  <div className="mb-6  flex space-x-4">
                    <div className="w-full">
                      <label
                        htmlFor="file"
                        className="block mb-2 text-sm font-medium"
                      >
                        Upload Logo
                      </label>
                      <input
                        onChange={handleImageChange}
                        type="file"
                        name="file"
                        className="w-full bg-white-100 border border-gray-300 text-gray-700 text-sm rounded-lg p-2"
                      />
                    </div>

                    <div className="w-full">
                      <label
                        htmlFor="companyName"
                        className="block mb-2 text-sm font-medium "
                      >
                        Company Size
                      </label>
                      <select
                        className="w-full bg-white-100 border border-gray-300 text-gray-700 text-sm rounded-lg p-2"
                        value={form.companySize}
                        onChange={(e) =>
                          setForm({ ...form, companySize: e.target.value })
                        }
                      >
                        <option value="0-10">Less than 10</option>
                        <option value="10-50">10-50</option>
                        <option value="50-100">50-200</option>
                        <option value="100-500">200-500</option>
                        <option value="500-1000">500-1000</option>
                        <option value="1000+">1000+</option>
                      </select>
                    </div>
                  </div>
                  <div className="mb-6  flex space-x-4">
                    <div className="w-full">
                      <label
                        htmlFor="address"
                        className="block mb-2 text-sm font-medium"
                      >
                        Address
                      </label>
                      <textarea
                        type="text"
                        value={form.address}
                        onChange={(e) =>
                          setForm({ ...form, address: e.target.value })
                        }
                        rows={5}
                        cols={20}
                        name="address"
                        className="w-full bg-white-100 border border-gray-300 text-gray-700 text-sm rounded-lg p-2"
                      />
                    </div>
                  </div>
                </div>
                <div className="mb-6 flex justify-center">
                  <button
                    type="submit"
                    className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    Submit
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
        <Footer showBookingSlot={true} />
      </div>
    </div>
  );
}
