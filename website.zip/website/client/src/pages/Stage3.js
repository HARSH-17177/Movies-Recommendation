import React, { useState, useRef, useEffect } from "react";
import problem from "../images/problem.png";
import {
  uploadFile,
  getSignedUrl,
  getConfidence,
  getStage3Question,
  getStage3Fluency,
} from "../service/mlAPI";
import CountdownTimer from "../components/portal/CountdownTimer";
import { TopNavigation } from "../components/NavBar/TopNavigation";
import TabSwitch from "../components/portal/TabSwitch";
import { useNavigate, useLocation } from "react-router-dom";

const mimeType = 'video/webm; codecs="opus,vp8"';

export default function Stage3() {
  const location = useLocation();
  const videoRef = useRef(null);
  const liveVideoFeed = useRef(null);
  const mediaRecorder = useRef(null);
  const [url, setUrl] = useState("");

  const [permission, setPermission] = useState(false);
  const [recordingStatus, setRecordingStatus] = useState("inactive");
  const streamRef = useRef(null);
  const [recordedVideo, setRecordedVideo] = useState(null);
  const [videoChunks, setVideoChunks] = useState([]);
  const [videoBlob, setVideoBlob] = useState(null);
  const randomQuestion = useRef(null);
  const timerIdRef = useRef(null);
  const localVideoChunksRef = useRef([]);
  const navigate = useNavigate();

  const fetchData = async () => {
    await getCameraPermission();
    console.log("after camera permission");
    // Retrieve the state from the previous page
    const state = location.state;
    console.log(state);

    // If questionsArray is not present, fetch questions using the API
    if (!state || !state.questionsArray) {
      console.log("no state found");
      const cookieVal = getCookie();
      await getStage3Question(cookieVal);
      await startRecording();
    } else {
      console.log("State found");
      // Use questionsArray from the previous page
      randomQuestion.current = state.questionsArray;
      await startRecording();
    }
  };

  useEffect(() => {
    fetchData();
  }, [location]);
  const startTimer = () => {
    // Clear any existing timer
    if (timerIdRef.current) {
      clearTimeout(timerIdRef.current);
    }

    // Start a new timer and store its ID
    const newTimerId = setTimeout(() => {
      console.log("Timer expired!");
      stopRecording();
    }, 60000);

    timerIdRef.current = newTimerId;
  };

  const resetTimer = () => {
    // Clear the timer if it exists
    if (timerIdRef.current) {
      clearTimeout(timerIdRef.current);
      timerIdRef.current = null; // Reset the timer ID
    }
  };
  //when we get video then upload it to aws
  const AWSUpload = async (Blob, url) => {
    console.log("upload function start");
    if (Blob) {
      console.log(url);
      await uploadFile(url, Blob);
      setUrl(url.split("?")[0]);
      console.log("upload function end");
    }
  };

  const getCameraPermission = async () => {
    setRecordedVideo(null);

    if ("MediaRecorder" in window) {
      try {
        const videoConstraints = {
          audio: false,
          video: true,
        };
        const audioConstraints = { audio: true };

        const audioStream = await navigator.mediaDevices.getUserMedia(
          audioConstraints
        );
        const videoStream = await navigator.mediaDevices.getUserMedia(
          videoConstraints
        );

        setPermission(true);

        const combinedStream = new MediaStream([
          ...videoStream.getVideoTracks(),
          ...audioStream.getAudioTracks(),
        ]);

        streamRef.current = combinedStream;

        liveVideoFeed.current.srcObject = videoStream;
      } catch (err) {
        alert(err.message);
      }
    } else {
      alert("The MediaRecorder API is not supported in your browser.");
    }
  };

  const startRecording = async () => {
    startTimer();
    setRecordingStatus("recording");

    const media = new MediaRecorder(streamRef.current, { mimeType });
    mediaRecorder.current = media;
    mediaRecorder.current.start();

    mediaRecorder.current.ondataavailable = (event) => {
      if (typeof event.data === "undefined") return;
      if (event.data.size === 0) return;
      localVideoChunksRef.current = [];
      localVideoChunksRef.current.push(event.data);
    };

    setVideoChunks(localVideoChunksRef.current);
  };

  const stopRecording = () => {
    setPermission(false);
    setRecordingStatus("inactive");
    mediaRecorder.current.stop();

    mediaRecorder.current.onstop = async () => {
      const vidBlob = new Blob(localVideoChunksRef.current, { type: mimeType });
      const videoUrl = URL.createObjectURL(vidBlob);

      setRecordedVideo(videoUrl);
      setVideoBlob(vidBlob);
      setVideoChunks([]);
      resetTimer();
      let cookieVal = getCookie();
      const response = await getSignedUrl("stage_3", cookieVal);
      await AWSUpload(vidBlob, response.url);
      console.log("After the Upload function in Stop recording");
      getConfidence(cookieVal);
      getStage3Fluency(cookieVal);
      navigate("/dashboard");
    };
  };

  const getCookie = () => {
    const cookieValue = document.cookie
      .split("; ")
      .find((row) => row.startsWith("token="))
      .split("=")[1];
    return cookieValue;
  };

  return (
    <div className="bg-gray-50">
      <TopNavigation
        showAvatar={true}
        handleLogout={() => navigate("/login")}
      />
      <TabSwitch />
      <div>
        <div className="flex flex-col items-center justify-center bg-gray-50 min-h-fit min-w-full">
          <img
            src={problem}
            alt="Question vector Image"
            className="max-w-min max-h-min ml-8 mt-2"
          />
          <CountdownTimer initialTime={80} className="max-h-fit" />

          <div className="bg-white rounded-3xl shadow-2xl p-4 m-10 mt-2">
            <h3 className="text-black p-2 m-2">
              {randomQuestion ? (
                <div>
                  <p>{randomQuestion.current}</p>
                </div>
              ) : (
                <p>Loading random question...</p>
              )}
            </h3>
          </div>
          <div className="w-fit h-fit sm:w-3/5 sm:h-auto md:aspect-w-16/9 sm:aspect-h-9/16 bg-gray-500">
            <video ref={liveVideoFeed} autoPlay className="live-player"></video>
          </div>

          <div className="mt-4">
            {recordingStatus === "recording" ? (
              <button
                onClick={stopRecording}
                className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
              >
                END TEST
              </button>
            ) : null}
          </div>
        </div>
        <h3>Video rendered using AWS link</h3>

        {videoBlob && (
          <video width="400" height="200" controls src={url}>
            Browser not supported
          </video>
        )}
      </div>
    </div>
  );
}
