import React, { useState, useEffect, useRef } from "react";
import { TopNavigation } from "../../components/NavBar/TopNavigation";
import InstructMCQ from "../../components/portal/InstructMCQ";
import {
  getStage2Excel,
  getStage2Analytical,
  getStage2Reasoning,
} from "../../service/mlAPI";
import { useNavigate } from "react-router-dom";

export default function InstructionMCQ() {
  const [permission, setPermission] = useState(false);
  const liveVideoFeed = useRef(null);
  const [stream, setStream] = useState(null);
  const [buttonDisabled, setButtonDisabled] = useState(true);
  const [recordedVideo, setRecordedVideo] = useState(null);
  const allQuestions = useRef([]);
  const navigate = useNavigate();
  const questionsArray = useRef([]);
  const getQuestionsFromOpenAI = async (data) => {
    try {
      const q7Promise = getStage2Excel(data);
      const q8Promise = getStage2Reasoning(data);
      const q6Promise = getStage2Analytical(data);

      // Use Promise.all to fetch questions in parallel
      const [q7, q8, q6] = await Promise.all([q7Promise, q8Promise, q6Promise]);
      allQuestions.current = [...q7, ...q8, ...q6];
      console.log(allQuestions.current);
      questionsArray.current = q6;
    } catch (error) {
      console.log("Error getting questions from OpenAI", error.message);
    }
  };
  const getCookie = () => {
    const cookieValue = document.cookie
      .split("; ")
      .find((row) => row.startsWith("token="))
      .split("=")[1];
    return cookieValue;
  };
  const getCameraPermission = async () => {
    try {
      const videoConstraints = {
        audio: true,
        video: true,
      };

      const stream = await navigator.mediaDevices.getUserMedia(
        videoConstraints
      );
      setPermission(true);

      let cookieVal = getCookie();
      await getQuestionsFromOpenAI(cookieVal);
      setButtonDisabled(false);
    } catch (err) {
      alert(err.message);
    }
  };

  const handleStartTest = () => {
    // Pass questionsArray to the next page and navigate
    navigate("/mcq", { state: { allQuestions: allQuestions.current } });
  };

  useEffect(() => {
    getCameraPermission();
  }, []);
  return (
    <div className="bg-gray-100 h-screen">
      <TopNavigation
        showAvatar={true}
        handleLogout={() => navigate("/login")}
      />
      <div className="px-12">
        <InstructMCQ />
        {/* Start Test Button */}
        <div className="mt-4 flex justify-center">
          <button
            disabled={buttonDisabled}
            onClick={handleStartTest}
            className={`${
              buttonDisabled
                ? "bg-gray-300 cursor-not-allowed"
                : "bg-blue-500 hover:bg-blue-700"
            } text-white font-bold py-2 px-4 rounded`}
          >
            Start Test
          </button>
        </div>
      </div>
    </div>
  );
}
