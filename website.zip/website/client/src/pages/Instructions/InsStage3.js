import React, { useState, useEffect, useRef } from "react";
import { TopNavigation } from "../../components/NavBar/TopNavigation";
import InstructVideo from "../../components/portal/InstructVideo";
import { useNavigate } from "react-router-dom";
import { getStage3Question } from "../../service/mlAPI";

export default function InStage3() {
  const randomQuestion = useRef(null);
  const [buttonDisabled, setButtonDisabled] = useState(true);
  const questionsArray = useRef([]);
  const [recordedVideo, setRecordedVideo] = useState(null);
  const navigate = useNavigate();

  const getCookie = () => {
    const cookieValue = document.cookie
      .split("; ")
      .find((row) => row.startsWith("token="))
      .split("=")[1];
    return cookieValue;
  };

  const getCameraPermission = async () => {
    let cookieVal = getCookie();
    const ques = await getStage3Question(cookieVal);
    randomQuestion.current = ques.ques1;
    setRecordedVideo(null);
    if ("MediaRecorder" in window) {
      try {
        const videoConstraints = {
          audio: false,
          video: true,
        };
        const audioConstraints = { audio: true };
        // create audio and video streams separately
        const audioStream = await navigator.mediaDevices.getUserMedia(
          audioConstraints
        );
        const videoStream = await navigator.mediaDevices.getUserMedia(
          videoConstraints
        );

        setButtonDisabled(false); // Enable the button when the streams are obtained
      } catch (err) {
        console.error("Error accessing camera", err.message);
        return;
      }
    } else {
      console.error("The MediaRecorder API is not supported in your browser.");
      // Display an error message on the UI or handle it as needed
      return;
    }
  };

  const handleStartTest = () => {
    // Pass questionsArray to the next page and navigate
    navigate("/stage3", { state: { questionsArray: randomQuestion.current } });
  };

  useEffect(() => {
    getCameraPermission();
  }, []);

  return (
    <div className="bg-gray-100 h-screen">
      <TopNavigation
        showAvatar={true}
        handleLogout={() => navigate("/login")}
      />
      <div className="px-12">
        <InstructVideo />
        {/* Start Test Button */}
        <div className="mt-4 flex justify-center">
          <button
            disabled={buttonDisabled}
            onClick={handleStartTest}
            className={`${
              buttonDisabled
                ? "bg-gray-300 cursor-not-allowed"
                : "bg-blue-500 hover:bg-blue-700"
            } text-white font-bold py-2 px-4 rounded`}
          >
            Start Test
          </button>
        </div>
      </div>
    </div>
  );
}
