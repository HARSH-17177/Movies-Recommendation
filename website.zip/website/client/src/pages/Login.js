import React from "react";
import Auth from "./Auth"; // Import the modified component
import { TopNavigation } from "../components/NavBar/TopNavigation";
import { Footer } from "../components/Footer";

function Login() {
  return (
    <div className="bg-gray-50">
      <TopNavigation />
      <Auth />
    </div>
  );
}

export default Login;
