import React, { useEffect, useState } from "react";
import { uploadFile } from "../service/mlAPI";
import { getSignedUrlResume } from "../service/resumeAPI";
import { TopNavigation } from "../components/NavBar/TopNavigation";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";


export default function Stage1() {
  const navigate = useNavigate();
  const [url, setUrl] = useState("");
  const [file, setFile] = useState("");

  const getCookie = () => {
    const cookieValue = document.cookie
      .split("; ")
      .find((row) => row.startsWith("token="))
      .split("=")[1];
    return cookieValue;
  };
  useEffect(() => {
    const getData = async () => {
      let cookieVal = getCookie();
      const response = await getSignedUrlResume(cookieVal);
      setUrl(response.url);
    };
    getData();
  }, [file]);

  useEffect(() => {
    const getData = async () => {
      try {
       await uploadFile(url, file);
          toast.success("File uploaded successfully");
          navigate("/resume-data");
        
      } catch (error) {
        console.error("Error uploading file:", error);
      }
    };
    file && getData();
  }, [file, url, navigate]);

  return (
    <div className="bg-gray-50">
      <TopNavigation showAvatar={true}  handleLogout={() => navigate("/login")}/>
      {/*Submit Resume through browse feature */}
      <div className="bg-gray-50 min-h-screen flex items-center justify-center">
        <link
          rel="stylesheet"
          href="https://unpkg.com/flowbite@1.4.4/dist/flowbite.min.css"
        />

        <div className="max-w-2xl mx-auto p-2">
          <div className="flex items-center justify-center w-full">
            <label
              for="dropzone-file"
              className="flex flex-col items-center justify-center w-full h-64 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-100 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-200 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600 p-4"
            >
              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                <svg
                  className="w-10 h-10 mb-3 text-gray-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                  ></path>
                </svg>
                <p className="mb-2 text-sm text-gray-500 dark:text-gray-400">
                  <span className="font-semibold">Click to upload</span> or drag
                  and drop
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  PDF format Resume (Max. 5 Mb)
                </p>
              </div>
              <input
                id="dropzone-file"
                type="file"
                className="hidden"
                onChange={(e) => {
                  const selectedFile = e.target.files[0];
                  if (selectedFile && selectedFile.type === "application/pdf") {
                    setFile(selectedFile);
                  } else {
                    // Display an error message or clear the selected file
                    alert("Please select a PDF file.");
                    e.target.value = null; // Clear the file input
                  }
                }}
                accept=".pdf"
              />
            </label>
          </div>

          <p className="mt-5 text-center">
            Kindly utilize the provided DropZone to submit your resume, ensuring
            it is in <span className="font-bold">PDF format </span>with a{" "}
            <span className="font-bold italic">(.pdf) extension.</span>
          </p>
        </div>
      </div>
    </div>
  );
}
