import React, { useEffect, useState } from "react";
import Card from "../../components/portal/Card";
import { Footer } from "../../components/Footer";
import Filter from "../../components/portal/Filter";
import { getAllJobPostings } from "../../service/api";
import "../../components/customCss/listingPage.css";
import { useNavigate } from "react-router-dom";
import { MagnifyingGlass } from "react-loader-spinner";
import { MdArrowForwardIos, MdArrowBackIos } from "react-icons/md";
import CandidateNavbar from "../../components/NavBar/CandidateNavbar";


function Listing() {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [initialCounter, setInitialCounter] = useState(0);
  const [counter, setCounter] = useState(6);
  const navigate = useNavigate();
  useEffect(() => {
    const fetchJobs = async () => {
      setLoading(true);
      const jobs = await getAllJobPostings();
      setJobs(jobs.jobList);
      console.log(jobs.jobList);

      setLoading(false);
    };
    fetchJobs();
  }, []);

  const first5Data = jobs.slice(initialCounter, counter);

  return (
    <div className="bg-gray-100">
      {loading ? (
        <div className="magnifying-glass-wrapper flex flex-col items-center justify-center h-screen">
          <MagnifyingGlass
            visible={true}
            height="160"
            width="160"
            ariaLabel="MagnifyingGlass-loading"
            wrapperStyle={{}}
            wrapperClass="MagnifyingGlass-wrapper"
            glassColor="#c0efff"
            color="#2979FF"
          />
        </div>
      ) : (
        <div className="bg-gray-100 contain">
          <CandidateNavbar/>
          {/* Listing Page of Jobs with Filter */}
          <div className="lg:grid outer-contain lg:grid-cols-4 md:grid  md:grid-cols-4  bg-gray-100">
            {/* side bar */}

            <div className="sidebar lg:grid lg:grid-cols-1 md:grid md:grid-cols-1 h-screen bg-gray-100">
              <Filter />
            </div>
            {loading && <h1>Loading...</h1>}
            {!loading && jobs.length === 0 && <h1>No Jobs Found</h1>}

            {/* Job Description Cards */}
            <div className=" h-screen mb-2 inner-container lg:col-span-3 md:col-span-3 bg-gray-100 lg:mt-6">
              <div className="content grid grid-cols-3 gap-y-4 gap-x-12 lg:mr-4">
                {first5Data.map((job, index) => (
                  <Card
                    className="box"
                    key={index}
                    cardData={job}
                    navigate={navigate}
                    id={job._id}
                  />
                ))}
              </div>
              <div className="buttons w-100   flex justify-between lg:mt-3">
                <button
                  disabled={initialCounter === 0}
                  href="#"
                  className="ml-4 mb-2  rounded-md bg-blue-500 px-3.5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
                  onClick={() => {
                    setInitialCounter(initialCounter - 6);
                    setCounter(counter - 6);
                  }}
                >
                  <MdArrowBackIos />
                </button>
                <button
                  disabled={counter >= jobs.length}
                  href="#"
                  className="mr-4 mb-2 rounded-md  bg-blue-500 px-3.5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
                  onClick={() => {
                    setInitialCounter(initialCounter + 6);
                    setCounter(counter + 6);
                  }}
                >
                  <MdArrowForwardIos />
                </button>
              </div>
            </div>
            <div className="footer bg-gray-100 lg:row-start-2 lg:col-span-4 md:row-start-2 md:col-span-4">
              <Footer showBookingSlot={false} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Listing;
