import React from 'react'

function Slider() {
  return (
    <div>Slider</div>
  )
}

export default Slider;