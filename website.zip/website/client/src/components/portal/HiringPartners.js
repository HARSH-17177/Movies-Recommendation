import React from "react";
import ileads from "../../images/company/ileads_logo.png";
import intrainz from "../../images/company/intrainz_logo.png";
import level from "../../images/company/level_logo.png";
import NoBroker from "../../images/company/NoBroker_logo.png";

const HiringPartners = () => {
  return (
    <div className="bg-gray-100 py-4 text-center px-4">
      <div className="container mx-auto">
        <h2 className="text-2xl pt-8 font-bold text-gray-700 underline decoration-double mb-4 relative">
          Our Hiring Partners
        </h2>

        <div className="flex flex-wrap sm:px-0 px-16 py-4 justify-between">
          <div className="w-1/4 p-4">
            <img src={NoBroker} alt="NoBroker Logo" className="mx-auto h-12" />
            <p className="text-gray-600 font-bold text-md mt-2">NoBroker.com</p>
          </div>
          <div className="w-1/4 p-4">
            <img
              src={level}
              alt="Level Supermind Logo"
              className="mx-auto h-12"
            />
            <p className="text-gray-600 font-bold text-md mt-2">
              Level Supermind
            </p>
          </div>
          <div className="w-1/4 p-4">
            <img src={ileads} alt="iLeads Logo" className="mx-auto h-12" />
            <p className="text-gray-600 font-bold text-md mt-2">
              iLeads Auxilary Services
            </p>
          </div>
          <div className="w-1/4 p-4">
            <img src={intrainz} alt="inTrainz Logo" className="mx-auto h-12" />
            <p className="text-gray-600 font-bold text-md mt-2">inTrainz</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HiringPartners;
