import React from "react";

const InstructVideo = () => {
  return (
    <div className="bg-white border rounded-lg shadow-lg p-5">
      {/* Heading */}
      <h2 className="text-2xl text-gray-700 font-semibold">Instructions</h2>

      {/* Bullet Points with Instructions */}
      <ul className="list-decimal ml-6 mt-4">
        <li>
          The test will consist of 6 sections, including 3 sections of{" "}
          <span className="font-bold text-gray-800">Virtual Interview </span>{" "}
          and 3 sections of{" "}
          <span className="font-bold text-gray-800">MCQ tests.</span>
        </li>
        <li>
          Total time for the test is{" "}
          <span className="font-bold text-gray-800">
            approximately 25 minutes.{" "}
          </span>
          Please complete the test within 25 minutes.{" "}
          <span className="font-bold text-gray-800">
            Closing the test prematurely will lead to disqualification.
          </span>
        </li>
        <li>
          The test will be used to create a{" "}
          <span className="font-bold text-gray-800">"Proof-Of-Work"</span> for
          use in recruitment by different companies.
        </li>
        <li>
          The test is AI-Proctored, and{" "}
          <span className="font-bold text-gray-800">
            {" "}
            📷 camera and 🎤 audio{" "}
          </span>{" "}
          access are required for proctoring.
          <span className="font-bold text-gray-800">
            {" "}
            Do not attempt to cheat.
          </span>
        </li>
        <li>
          The website may{" "}
          <span className="font-bold text-gray-800"> detect tab changes</span>,
          so avoid changing tabs during the test, as it may{" "}
          <span className="font-bold text-gray-800">
            {" "}
            lead to disqualification.
          </span>
        </li>
        <li>
          The test evaluates you on 8 parameters:{" "}
          <span className="font-bold text-blue-500">Subject Knowledge</span>,{" "}
          <span className="font-bold text-green-600">Excel Skill</span>,{" "}
          <span className="font-bold text-red-500">Analytical Skill</span>,{" "}
          <span className="font-bold text-purple-600">
            Problem Solving Skills
          </span>
          ,{" "}
          <span className="font-bold text-orange-600">Real Life Situation</span>
          , <span className="font-bold text-pink-600">Communication Skill</span>
          , <span className="font-bold text-teal-600">Confidence Level</span>,
          and <span className="font-bold text-yellow-600">Creativity</span>.
        </li>
        <li>
          <span className="font-bold text-red-400">
            Ensure you are seated in a place with proper lighting or else you
            may get a wrong score.
          </span>
        </li>
        <li>
          <span className="font-bold text-gray-800"> Section A:</span> It
          consists of 2 questions on Sales and Marketing Skills, to be answered
          in 🎤 audio and 📷 video format. You have a{" "}
          <span className="font-bold text-gray-800"> maximum of 1 minute </span>{" "}
          to answer each question. If you complete a question before 1 minute,
          you can move to the next question.
        </li>
      </ul>
      <div className="text-2xl font-semibold text-gray-700 text-center py-2">
        All the Best for Exam{" "}
        <span role="img" aria-label="Thumbs Up">
          👍
        </span>
      </div>

   
    </div>
  );
};

export default InstructVideo;
