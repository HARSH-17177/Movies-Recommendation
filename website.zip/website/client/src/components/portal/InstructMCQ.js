import React from "react";

const InstructMCQ = ({ startTest }) => {
  return (
    <div className="bg-white border rounded-lg shadow-lg p-5">
      {/* Heading */}
      <h2 className="text-2xl text-gray-700 font-semibold">Instructions</h2>

      {/* Bullet Points with Instructions and Context */}
      <ul className="list-decimal ml-6 mt-4">
        <li>
          <span className="font-bold text-gray-800">
            The exam will have further 3 sections in MCQ Form questions
          </span>
        </li>
        <li>
          <span className="font-bold text-gray-800">
            The exam will have audio and video access to the computer
          </span>{" "}
          and it will be{" "}
          <span className="font-bold text-gray-800">AI-proctored</span>. 🚫 So
          don't try to cheat in between. 🚫
        </li>
        <li>
          <span className="font-bold text-gray-800">
            The test has tab change enable
          </span>{" "}
          which detects the tab change and it may lead to disqualification if
          you switch it for more than{" "}
          <span className="font-bold text-gray-800">3 times</span>.
        </li>
        <li>
          <span className="font-bold text-gray-800">
            The MCQ question consists of 3 Sections with 4 questions each
          </span>
          , consisting of{" "}
          <span className="font-bold text-gray-800">
            12 Questions of MCQ Type
          </span>
          .
        </li>
        <li>
          You'll have{" "}
          <span className="font-bold text-gray-800">30 seconds</span> for
          answering each question.
        </li>
        <li>
          <span className="font-bold text-gray-800">Section B:</span> It will
          consist of questions related to{" "}
          <span className="font-bold text-blue-500">
            MS Excel or Google Sheets
          </span>{" "}
          and it will judge your knowledge in{" "}
          <span className="font-bold text-green-600">Excel Skill</span>.
        </li>
        <li>
          <span className="font-bold text-gray-800">Section C:</span> It
          consists of questions related to{" "}
          <span className="font-bold text-red-500">Data Analysis</span>. Please
          keep 🖋️ <span className="font-bold text-gray-800">Pen/Pencil</span>{" "}
          and <span className="font-bold text-gray-800">Rough sheet</span> for
          faster calculation of these Questions. It will judge your{" "}
          <span className="font-bold text-purple-600">Analytical Skill</span>.
        </li>
        <li>
          <span className="font-bold text-gray-800">Section D:</span> It
          consists of{" "}
          <span className="font-bold text-orange-600">Reasoning questions</span>{" "}
          of <span className="font-bold text-gray-800">EASY level</span>. Please
          keep your attention on words in this section and don't forget to keep{" "}
          <span className="font-bold text-gray-800">Pen/Pencil</span> and{" "}
          <span className="font-bold text-gray-800">Rough paper</span> for this
          stage.
        </li>
        <li>
          <span className="font-bold text-red-400">
          Ensure you are seated in a place with proper lighting or else you
            may get a wrong score.💡
          </span>
        </li>
      </ul>

      {/* Important Note */}
      <p className="text-gray-600 mt-4">
        The maximum time for all three sections is{" "}
        <span className="font-bold text-gray-800">6 Minutes</span>,{" "}
        <span className="font-bold text-gray-800">2 Minutes</span> for each
        section.
      </p>
      <div className="text-2xl font-semibold text-gray-700 text-center py-2">
        All the Best for Exam{" "}
        <span role="img" aria-label="Thumbs Up">
          👍
        </span>
      </div>
     
    </div>
  );
};

export default InstructMCQ;
