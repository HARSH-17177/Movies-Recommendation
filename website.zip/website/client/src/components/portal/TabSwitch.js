import React, { useEffect } from 'react';

const TabSwitch = () => {
  const handleVisibilityChange = () => {
    if (document.hidden) {
      // The tab has been switched, show an alert or perform any action you want.
      alert("Tab Switch Detected! Please note that continuing may result in the exam being closed.");
    }
  };

  useEffect(() => {
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  return null; // TabSwitch component doesn't render anything in the DOM
};

export default TabSwitch;
