import React, { useState,useRef, useEffect } from "react";
import Modal from "../../components/dashboard/Modal";
import { getAllJobsPosted, getAllCandidatesApplied, toggleShortlistedStatus} from "../../service/api";
import "../customCss/applicant.css";

const Candidates = () => {
  const [shortlisted, setShortlisted] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [jobId, setJobId] = useState("");
  const [candidatesData, setCandidatesData] = useState([]);
  const selectedCandidateRef = useRef();
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const token = getCookie();
    const getAllJobsPost = async (token) => {
      const getjobs = await getAllJobsPosted(token);
      setJobs(getjobs);
    };
    getAllJobsPost(token);
  }, []);

  useEffect(() => {
    const fetchCandidatesData = async () => {
      if (jobId) {
        const candidates = await getAllCandidatesApplied(jobId);
        setCandidatesData(candidates);
      }
    };
    fetchCandidatesData();
  }, [jobId]);

  const getCookie = () => {
    const cookieValue = document.cookie
      .split("; ")
      .find((row) => row.startsWith("token="));
    if (cookieValue) {
      return cookieValue.split("=")[1];
    } else {
      return null;
    }
  };

  const toggleShortlist = async (index) => {
    const candidateId = candidatesData[index].candidate.user;
    const updatedShortlisted = [...shortlisted];
    updatedShortlisted[index] = !updatedShortlisted[index];
    setShortlisted(updatedShortlisted);

    try {
      // Assuming toggleShortlistStatus is a function that makes an API call to update shortlist status
      await toggleShortlistedStatus(jobId, candidateId);
      console.log(jobId);
      console.log(candidateId);
    } catch (error) {
      console.error("Error toggling shortlist status:", error);
      // Handle error, e.g., show a notification to the user
    }
  };


  const openModal = (candidate) => {
    selectedCandidateRef.current = candidate;
    setIsModalOpen(true);
  };

  const closeModal = () => {
    selectedCandidateRef.current = null;
    setIsModalOpen(false);
  };

  const handleSelectChange = (event) => {
    setJobId(event.target.value);
  };
  console.log(selectedCandidateRef.current)
  return (
    <div className="bg-white border rounded-lg shadow-lg mb-3 p-5">
      {/* Top Section with Dropdown */}
      <div className="flex justify-between candidate-heading items-center">
        <div className="relative">
          <label
            className="text-2xl text-gray-700 font-semibold"
            htmlFor="jobRoles"
          >
            Job Roles
          </label>
          <select
            id="jobRoles"
            className="block appearance-none w-full bg-white border border-gray-300 text-gray-700 py-2 px-3 pr-8 rounded-lg leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
            onChange={handleSelectChange}
            value={jobId} // Controlled component to set the selected value
          >
            <option className="text-blue-900" value="">
              Select a job
            </option>
            {jobs.map((job) => (
              <option key={job._id} value={job._id}>
                {job.jobTitle}
              </option>
            ))}
          </select>
        </div>
        <div className="flex space-x-4 text-gray-600">
          {/* Abbreviations */}
          <div>
            P1 = Subject Knowledge, P2= Excel Knowledge, P3= Analytical Skill,
             P5 = Communication (A,B,C) <br></br>
             P4=Problem Solving,  P6= Confident : '😎' Not Confident: '😟' , P7= Creativity, P8=
            Resume Score.
          </div>
        </div>
      </div>

      {/* Candidate Table */}
      <div className="overflow-x-auto mt-5">
        <table className="min-w-full bg-white table-auto">
          <thead>
            <tr>
              <th className="border border-gray-300 p-2">SNo.</th>
              <th className="border border-gray-300 p-2">Name</th>
              <th className="border border-gray-300 p-2">Email</th>
              <th className="border border-gray-300 p-2">Score</th>
              <th className="border border-gray-300 p-2">P1</th>
              <th className="border border-gray-300 p-2">P2</th>
              <th className="border border-gray-300 p-2">P3</th>
              <th className="border border-gray-300 p-2">P4</th>
              <th className="border border-gray-300 p-2">P5</th>
              <th className="border border-gray-300 p-2">P6</th>
              <th className="border border-gray-300 p-2">P7</th>
              <th className="border border-gray-300 p-2">P8</th>
              <th className="border border-gray-300 p-2">PoW</th>
              <th className="border border-gray-300 p-2">Shortlist</th>
            </tr>
          </thead>
          <tbody>
            {candidatesData.map((candidate, index) => (
              <tr key={index}>
                <td className="border border-gray-300 p-2 text-center">
                  {index+1}
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  {candidate.candidate.name}
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  {candidate.candidate.email}
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  {(((candidate.candidate.role_related.score.ques1.score + candidate.candidate.role_related.score.ques2.score)/2)+(candidate.candidate.scoreExcel)+(candidate.candidate.scoreAnalytical)+(candidate.candidate.scoreReasoning)+((candidate.candidate.creative_related.score.ques1.score + candidate.candidate.creative_related.score.ques2.score)/2)+(candidate.candidate.resume_score)).toFixed(2)}
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  {(candidate.candidate.role_related.score.ques1.score + candidate.candidate.role_related.score.ques2.score)/2}
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  {candidate.candidate.scoreExcel}
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  {candidate.candidate.scoreAnalytical}
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  {candidate.candidate.scoreReasoning}
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  {candidate.candidate.fluency_score === 2 ? 'A' : candidate.candidate.fluency_score === 1 ? 'B' : candidate.candidate.fluency_score === 0 ? 'C' : ''}
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  {candidate.candidate.confidence_score > 40 ? '😎' : '😟'}
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  {(candidate.candidate.creative_related.score.ques1.score + candidate.candidate.creative_related.score.ques2.score)/2}
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  {(candidate.candidate.resume_score).toFixed(2)}
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  <button
                    onClick={() => openModal(candidate)}
                    className="text-blue-500 hover:underline cursor-pointer"
                  >
                    View PoW
                  </button>
                  <Modal isOpen={isModalOpen} closeModal={closeModal} candidateRef={selectedCandidateRef} />
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  <button
                    className={`text-gray-500 hover:text-red-500 ${
                      shortlisted[index] ? "text-red-500" : ""
                    }`}
                    onClick={() => toggleShortlist(index)}
                  >
                    {shortlisted[index] ? (
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="red"
                        viewBox="0 0 24 24"
                        stroke-width="1.5"
                        className="w-6 h-6"
                      >
                        <path
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          d="M11.48 3.499a.562.562 0 011.04 0l2.125 5.111a.563.563 0 00.475.345l5.518.442c.499.04.701.663.321.988l-4.204 3.602a.563.563 0 00-.182.557l1.285 5.385a.562.562 0 01-.84.61l-4.725-2.885a.563.563 0 00-.586 0L6.982 20.54a.562.562 0 01-.84-.61l1.285-5.386a.562.562 0 00-.182-.557l-4.204-3.602a.563.563 0 01.321-.988l5.518-.442a.563.563 0 00.475-.345L11.48 3.5z"
                        />
                      </svg>
                    ) : (
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                        className="w-6 h-6"
                      >
                        <path
                          fill-rule="evenodd"
                          d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z"
                          clip-rule="evenodd"
                        />
                      </svg>
                    )}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Candidates;
