import React, { useEffect, useRef, useState } from "react";
import classes from "./modal.module.css";
import icon from "../../images/icon.png";
import DonutChart from "../portal/DonutChart";

const Modal = ({ isOpen, closeModal, candidateRef }) => {
  const [isSkills, setIsSkills] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    dob: "",
    mobno: "",
    email: "",
    college: "",
    collegedegree: "",
    collegeyear: "",
    collegecgpa: "",
    school: "",
    schooldegree: "",
    schoolyear: "",
    schoolcgpa: "",
    exe1: "",
    exedes1: "",
    exe2: "",
    exedes2: "",
    res: "",
    resdes: "",
    achievement1: "",
    achievement1des: "",
    achievement2: "",
    achievement2des: "",
    certificate: "",
    certificatedes: "",
    project: "",
    projectdes: "",
    skills: [],
  });
  useEffect(() => {
    // Check if the modal is open and candidateRef.current is not undefined
    if (isOpen && candidateRef.current) {
      // data fetch from useRef
      let name = candidateRef.current.candidate.name;
      let email = candidateRef.current.candidate.email;
      let dob = candidateRef.current.candidate.dob;
      let mobno = candidateRef.current.candidate.mobno;
      let college = candidateRef.current.candidate.college;
      let collegedegree = candidateRef.current.candidate.collegedegree;
      let collegeyear = candidateRef.current.candidate.collegeyear;
      let collegecgpa = candidateRef.current.candidate.collegecgpa;
      let school = candidateRef.current.candidate.school;
      let schooldegree = candidateRef.current.candidate.schooldegree;
      let schoolyear = candidateRef.current.candidate.schoolyear;
      let schoolcgpa = candidateRef.current.candidate.schoolcgpa;
      let exe1 = candidateRef.current.candidate.exe1;
      let exedes1 = candidateRef.current.candidate.exedes1;
      let exe2 = candidateRef.current.candidate.exe2;
      let exedes2 = candidateRef.current.candidate.exedes2;
      let res = candidateRef.current.candidate.res;
      let resdes = candidateRef.current.candidate.resdes;
      let achievement1 = candidateRef.current.candidate.achievement1;
      let achievement1des = candidateRef.current.candidate.achievement1des;
      let achievement2 = candidateRef.current.candidate.achievement2;
      let achievement2des = candidateRef.current.candidate.achievement2des;
      let certificate = candidateRef.current.candidate.certificate;
      let certificatedes = candidateRef.current.candidate.certificatedes;
      let project = candidateRef.current.candidate.project;
      let projectdes = candidateRef.current.candidate.projectdes;
      let skills = candidateRef.current.candidate.skills;
      if (skills.length > 0) {
        setIsSkills(true);
      }
      console.log("data = ", candidateRef.current);
      // set Form Data to Display
      setFormData({
        name: name,
        email: email,
        dob: dob,
        mobno: mobno,
        college: college,
        collegedegree: collegedegree,
        collegeyear: collegeyear,
        collegecgpa: collegecgpa,
        school: school,
        schooldegree: schooldegree,
        schoolyear: schoolyear,
        schoolcgpa: schoolcgpa,
        exe1: exe1,
        exedes1: exedes1,
        exe2: exe2,
        exedes2: exedes2,
        res: res,
        resdes: resdes,
        achievement1: achievement1,
        achievement1des: achievement1des,
        achievement2: achievement2,
        achievement2des: achievement2des,
        certificate: certificate,
        certificatedes: certificatedes,
        project: project,
        projectdes: projectdes,
        skills: skills,
      });
    }
  }, [isOpen, candidateRef]);

  const options = {
    plotOptions: {
      radialBar: {
        offsetY: 0,
        startAngle: 0,
        endAngle: 270,
        hollow: {
          margin: 5,
          size: "20%",
          background: "transparent",
          image: undefined,
        },
        dataLabels: {
          name: {
            show: false,
          },
          value: {
            show: false,
          },
        },
      },
    },
    colors: [
      "#FD0100",
      "#F76915",
      "#b85042",
      "#2FA236",
      "#333ED4",
      "#011936ff",
    ],
    labels: [
      "Resume",
      "Excel Skills",
      "Subject Knowledge",
      "Creativity Score",
      "Analytical Skills",
      "Reasoning Skills",
    ],
    legend: {
      show: true,
      floating: true,
      fontSize: "16px",
      position: "left",
      offsetX: 20,
      offsetY: 0,
      labels: {
        useSeriesColors: true,
      },
      markers: {
        size: 0,
      },
      formatter: function (seriesName, opts) {
        return seriesName + ":  " + opts.w.globals.series[opts.seriesIndex];
      },
      itemMargin: {
        vertical: 3,
      },
    },
    responsive: [
      {
        breakpoint: 480,
        options: {
          legend: {
            show: false,
          },
        },
      },
    ],
  };
  const resume_score = candidateRef?.current?.candidate?.resume_score || 0;
  const analytical_score =
    candidateRef?.current?.candidate?.scoreAnalytical ? candidateRef.current.candidate.scoreAnalytical * 50 : 0;
    const excelScore = candidateRef?.current?.candidate?.scoreExcel
    ? candidateRef.current.candidate.scoreExcel * 25
    : 0;
  
  const reasoningScore = candidateRef?.current?.candidate?.scoreReasoning
    ? candidateRef.current.candidate.scoreReasoning * 50
    : 0;
  
  const creativeScore =
    candidateRef?.current?.candidate?.creative_related?.score?.ques1?.score &&
    candidateRef?.current?.candidate?.creative_related?.score?.ques2?.score
      ? 10 * ((candidateRef.current.candidate.creative_related.score.ques1.score + candidateRef.current.candidate.creative_related.score.ques2.score) / 2)
      : 0;
  
  const subjectScore =
    candidateRef?.current?.candidate?.role_related?.score?.ques1?.score &&
    candidateRef?.current?.candidate?.role_related?.score?.ques2?.score
      ? 10 * ((candidateRef.current.candidate.role_related.score.ques1.score + candidateRef.current.candidate.role_related.score.ques2.score) / 2)
      : 0;
  
  
 
  const series = [
    resume_score,
    excelScore,
    subjectScore,
    creativeScore,
    analytical_score,
    reasoningScore,
  ];

  return (
    <>
      <div
        className={`fixed inset-0 flex items-center justify-center z-50 ${
          isOpen ? "opacity-100 visible" : "opacity-0 invisible"
        } transition-opacity duration-300`}
      >
        <div className="absolute w-4/5 h-3/4 bg-white rounded-lg shadow-md overflow-y-auto">
          <div className="flex justify-end">
            <button
              onClick={closeModal}
              className="m-2 text-gray-700 hover:text-red-500"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                fill="currentColor"
                className="bi bi-x"
                viewBox="0 0 16 16"
              >
                <path
                  fillRule="evenodd"
                  d="M4.293 4.293a1 1 0 0 1 1.414 0L8 6.586l2.293-2.293a1 1 0 1 1 1.414 1.414L9.414 8l2.293 2.293a1 1 0 0 1-1.414 1.414L8 9.414l-2.293 2.293a1 1 0 0 1-1.414-1.414L6.586 8 4.293 5.707a1 1 0 0 1 0-1.414z"
                />
              </svg>
            </button>
          </div>
          {/* Modal content goes here */}
          <div className="h-full">
            <div className={classes.container}>
              <div className={classes.box1}>
                <div className={classes.section1}>
                  <img
                    className={classes.image}
                    src={icon}
                    alt="Photo"
                    width={200}
                  />
                </div>
                <div className={classes.skills}>
                  <h1 className={classes.title}>{formData.name}</h1>
                  {/* <hr className={classes.divide} /> */}
                  <div className={classes.details}>
                    <p>Email : {formData.email}</p>
                  </div>
                  <div className={classes.info}>
                    <p>Number : {formData.mobno}</p>
                  </div>
                  <div className={classes.info}>
                    <p> DOB : {formData.dob}</p>
                  </div>
                </div>
                <div className={classes.skills}>
                  <h1 className={classes.title}>Skills</h1>
                  {/* <hr className={classes.divide} /> */}
                  {isSkills ? (
                    <div className={classes.details}>
                      <p>{formData.skills[0]} &nbsp;</p>
                      <p>{formData.skills[1]} &nbsp;</p>
                      <p>{formData.skills[2]} &nbsp;</p>
                      <p>{formData.skills[3]} &nbsp;</p>
                      <p>{formData.skills[4]} &nbsp;</p>
                      <p>{formData.skills[5]} &nbsp;</p>
                      <p>{formData.skills[6]} &nbsp;</p>
                      <p>{formData.skills[7]} &nbsp;</p>
                      <p>{formData.skills[8]} &nbsp;</p>
                    </div>
                  ) : (
                    <div className={classes.details}>
                      <p>No Skills</p>
                    </div>
                  )}
                </div>
                <div className={classes.education}>
                  <h1 className={classes.title}>Education Detail</h1>

                  {/* <hr className={classes.divide} /> */}
                  <div className={classes.eduDetails}>
                    <h3 className={classes.smtitle}>College</h3>
                    <div className={classes.sdetails}>
                      <div className={classes.sminfo}>
                        <p>Name</p>
                        <p>{formData.college}</p>
                      </div>
                      <div className={classes.sminfo}>
                        <p>Branch</p>
                        <p>{formData.collegedegree}</p>
                      </div>
                      <div className={classes.sminfo}>
                        <p>Year of Passing</p>
                        <p>{formData.collegeyear}</p>
                      </div>
                      <div className={classes.sminfo}>
                        <p>CGPA</p>
                        <p>{formData.collegecgpa}</p>
                      </div>
                    </div>
                  </div>
                  <div className={classes.eduDetails}>
                    <h3 className={classes.smtitle}>School</h3>
                    <div className={classes.sdetails}>
                      <div className={classes.sminfo}>
                        <p>Name</p>
                        <p>{formData.school}</p>
                      </div>
                      <div className={classes.sminfo}>
                        <p>Branch</p>
                        <p>{formData.schooldegree}</p>
                      </div>
                      <div className={classes.sminfo}>
                        <p>Year of Passing</p>
                        <p>{formData.schoolyear}</p>
                      </div>
                      <div className={classes.sminfo}>
                        <p>CGPA</p>
                        <p>{formData.schoolcgpa}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* <div>
            <DonutChart options={options} series={series} />
          </div> */}
              </div>
              <div className={classes.box2}>
                <h1 className={classes.title}>Experience</h1>
                <hr className={classes.divide} />
                <div className={classes.section}>
                  <div className={classes.part1}>
                    <div className={classes.expsection}>
                      <p>Name - {formData.exe1}</p>
                      <p className={classes.exedes1}>{formData.exedes1}</p>
                    </div>
                  </div>
                  <div className={classes.part2}>
                    <div className={classes.expsection}>
                      <p>Name - {formData.exe2}</p>
                      <p className={classes.exedes2}>{formData.exedes1}</p>
                    </div>
                  </div>
                </div>

                <h1 className={classes.title}>Responsibility</h1>
                <hr className={classes.divide} />
                <div className={classes.section}>
                  <div className={classes.part1}>
                    <p className={classes.subheading}>Responsibility 1</p>
                    <p>name - {formData.res}</p>
                    <p className={classes.des}>{formData.resdes}</p>
                  </div>
                </div>

                <h1 className={classes.title}>Achivement</h1>
                <hr className={classes.divide} />
                <div className={classes.section}>
                  <div className={classes.part1}>
                    <p className={classes.subheading}>Achivement 1</p>
                    <p>name - {formData.achievement1}</p>
                    <p className={classes.des}>{formData.achievement1des}</p>
                  </div>
                  <div className={classes.part2}>
                    <p className={classes.subheading}>Achivement 2</p>
                    <p>name - {formData.achievement2}</p>
                    <p className={classes.des}>{formData.achievement2des}</p>
                  </div>
                </div>

                <h1 className={classes.title}>Training & Certification</h1>
                <hr className={classes.divide} />
                <div className={classes.section}>
                  <div className={classes.part1}>
                    <p className={classes.subheading}>Certificate 1</p>
                    <p>name - {formData.certificate}</p>
                    <p className={classes.des}>{formData.certificatedes}</p>
                  </div>
                </div>
                <h1 className={classes.title}>Project</h1>
                <hr className={classes.divide} />
                <div className={classes.section}>
                  <div className={classes.part1}>
                    <p className={classes.subheading}>Project 1</p>
                    <p>name - {formData.project}</p>
                    <p className={classes.des}>{formData.projectdes}</p>
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.radialBar}>
              <DonutChart options={options} series={series} />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Modal;
