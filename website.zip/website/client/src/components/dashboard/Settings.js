import React from "react";
import ChangePassword from "./ChangePassword";
import { changePasswordEmployer } from "../../service/api";

function Settings() {
  return (
    <div className="pt-16">
      <ChangePassword  changePasswordApi={changePasswordEmployer}/>
    </div>
  );
}

export default Settings;
