import React, { useState } from 'react';
import { toast } from "react-toastify";


const ChangePassword = ({ changePasswordApi }) => {
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordMismatch, setPasswordMismatch] = useState(false);
  const [passwordShown, setPasswordShown] = useState(false);

  const getCookie = () => {
    const cookieValue = document.cookie
      .split("; ")
      .find((row) => row.startsWith("token="));
    return cookieValue ? cookieValue.split("=")[1] : null;
  };

  const token = getCookie();

  const handlePasswordChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case 'oldPassword':
        setOldPassword(value);
        break;
      case 'newPassword':
        setNewPassword(value);
        setPasswordMismatch(false);
        break;
      case 'confirmPassword':
        setConfirmPassword(value);
        setPasswordMismatch(value !== newPassword);
        break;
      default:
        break;
    }
  };

  const togglePasswordVisibility = () => {
    setPasswordShown(!passwordShown);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setPasswordMismatch(true);
    } else {
      try {
        const response =  await changePasswordApi(oldPassword, newPassword, token);
        if(response){
        console.log('Password updated successfully!');
        toast.success("Password Changed!")
    }else{
        toast.error("Password Incorrect!");
    }
      } catch (error) {
        console.error('Error updating password:', error);
        toast.error("Password Incorrect!");
      }
    }
  };

  return (
    <div className="w-full max-w-xs mx-auto shadow-2xl bg-gray-100 rounded-xl">
      <form onSubmit={handleSubmit} className="bg-white shadow-md rounded-xl px-8 pt-6 pb-8 mb-4">
       
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="oldPassword">
            Old Password
          </label>
          <input
            className="shadow appearance-none border rounded-xl w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="oldPassword"
            type="password"
            placeholder="******************"
            name="oldPassword"
            value={oldPassword}
            onChange={handlePasswordChange}
          />
        </div>
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="newPassword">
            New Password
          </label>
          <div className='relative'>
          <input
            className="shadow appearance-none border rounded-xl w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline"
            id="newPassword"
            type={passwordShown ? "text" : "password"}
            placeholder="******************"
            name="newPassword"
            value={newPassword}
            onChange={handlePasswordChange}
          />
          <svg
            onClick={togglePasswordVisibility}
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            fill="gray"
            className="bi bi-eye absolute top-1/2 right-3 -translate-y-1/2 cursor-pointer"
            viewBox="0 0 16 16"
          >
            {passwordShown ? (
              <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5 8-5.5 8-5.5z" />
            ) : (
              <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8z" />
            )}
            <path d="M3 8a5 5 0 0110 0H3z" />
          </svg>
          </div>
        </div>
        <div className="mb-6">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="confirmPassword">
            Confirm New Password
          </label>
          <input
            className="shadow appearance-none border rounded-xl w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="confirmPassword"
            type="password"
            placeholder="******************"
            name="confirmPassword"
            value={confirmPassword}
            onChange={handlePasswordChange}
          />
          {passwordMismatch && (
            <p className="text-red-500 text-xs italic">
              New Password and Confirm New Password should be same.
            </p>
          )}
        </div>
        <div className="flex items-center justify-between">
          <button
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-xl focus:outline-none focus:shadow-outline"
            type="submit"
          >
            Change Password
          </button>
        </div>
      </form>
    </div>
  );
};

export default ChangePassword;
