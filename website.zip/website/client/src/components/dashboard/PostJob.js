import React, { useState } from "react";
import axios from "axios";
import { getEmployerID } from "../../service/api";
import { toast } from 'react-toastify';
import "../customCss/employer_dashboard.css"
const API_URI = "http://localhost:8080/api/v1";

const PostJob = () => {
  const [postJob, setPostJob] = useState({
    jobTitle: "",
    workLocation: "",
    description: "",
    candidatePreferences: " 1.\n 2.\n 3. ",
    noteJD: " 1.\n 2.\n 3.",
    salary: "",
    variableSalary: "",
    workType: "Job",
    applicationDeadline: "",
    noOfPositions: "",
    perks: [],
  });

  // Universal change handler for all form inputs
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    if (type === "checkbox") {
      // Handling checkboxes separately
      setPostJob((prevFormData) => {
        const newPerks = checked
          ? [...prevFormData.perks, value]
          : prevFormData.perks.filter((perk) => perk !== value);

        return { ...prevFormData, [name]: newPerks };
      });
    } else {
      // Handling other inputs like text, number, date, etc.
      setPostJob((prevFormData) => ({
        ...prevFormData,
        [name]: value,
      }));
    }
  };
  const getCookie = () => {
    const cookieValue = document.cookie
      .split("; ")
      .find((row) => row.startsWith("token="));
    if (cookieValue) {
      return cookieValue.split("=")[1];
    } else {
      return null;
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Handle form submission here using the postJob state
    console.log(postJob);
    try {
      console.log("called");
      let cookieVal = getCookie();
      let user = await getEmployerID(cookieVal);
      const response = await axios.post(
        `${API_URI}/Employer/newJobPosting`,
        {
          ...postJob,
          employer: user,
        },
        {
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "http://localhost:3000",
          },
        }
      );
      console.log(response.data);
      toast.success("Job Posted!")
      return response.data;
    } catch (error) {
      console.log(error.response.data);
    }
  };
  return (
    <div className="mb-6">
      <h2 className="text-3xl font-semibold text-center text-gray-700 mb-4">
        Post a Job
      </h2>

      <div className="bg-white rounded-lg shadow-lg p-6">
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <div className="flex space-x-4">
              <div className="w-1/2">
                <label
                  htmlFor="role"
                  className="block text-gray-700 font-semibold"
                >
                  Job Title:
                </label>
                <input
                  type="text"
                  id="role"
                  name="jobTitle"
                  className="rounded-md border border-gray-300 p-2 w-full"
                  value={postJob.jobTitle}
                  onChange={handleChange}
                />
              </div>
              <div className="w-1/2">
                <label
                  htmlFor="workLocation"
                  className="block text-gray-700 font-semibold"
                >
                  Work Location:
                </label>
                <input
                  type="text"
                  id="workLocation"
                  name="workLocation"
                  className="rounded-md border border-gray-300 p-2 w-full"
                  value={postJob.workLocation}
                  onChange={handleChange}
                />
              </div>
            </div>
          </div>

          <div className="mb-4">
            <div className="flex space-x-4">
              <div className="w-full">
                <label
                  htmlFor="jobDescription"
                  className="block text-gray-700 font-semibold"
                >
                  Job Description:
                </label>
                <textarea
                  id="jobDescription"
                  name="description"
                  value={postJob.description}
                  onChange={handleChange}
                  className="rounded-md border border-gray-300 p-2 w-full"
                  rows="6"
                  placeholder="Write your Job Description in more than 2000 Characters"
                />
              </div>
            </div>
          </div>

          <div className="mb-4">
            <div className="flex space-x-4">
              <div className="w-1/2">
                <label
                  htmlFor="jobDescriptionNote"
                  className="block text-gray-700 font-semibold"
                >
                  Do you have any candidate preferences?:
                </label>
                <textarea
                  id="jobDescriptionNote"
                  className="rounded-md border border-gray-300 p-2 w-full"
                  name="candidatePreferences"
                  value={postJob.candidatePreferences}
                  onChange={handleChange}
                  rows="5"
                />
              </div>
              <div className="w-1/2">
                <label
                  htmlFor="jobDescriptionNote"
                  className="block text-gray-700 font-semibold"
                >
                  Note for Job Description:
                </label>
                <textarea
                  id="jobDescriptionNote"
                  className="rounded-md border border-gray-300 p-2 w-full"
                  name="noteJD"
                  rows="5"
                  value={postJob.noteJD}
                  onChange={handleChange}
                />
              </div>
            </div>
          </div>

          <div className="mb-4">
            <div className="flex space-x-4">
              <div className="w-1/2">
                <label
                  htmlFor="salary"
                  className="block text-gray-700 font-semibold"
                >
                  Salary/ Stipend (Per Month Basis):
                </label>
                <input
                  type="text"
                  id="salary"
                  name="salary"
                  className="rounded-md border border-gray-300 p-2 w-full"
                  placeholder="Base monthly salary"
                  value={postJob.salary}
                  onChange={handleChange}
                />
              </div>
              <div className="w-1/2">
                <label
                  htmlFor="variableSalary"
                  className="block text-gray-700 font-semibold"
                >
                  Any Variable Salary:
                </label>
                <input
                  type="number"
                  id="variableSalary"
                  name="variableSalary"
                  value={postJob.variableSalary}
                  onChange={handleChange}
                  className="rounded-md border border-gray-300 p-2 w-full"
                  placeholder="Any extra incentive?"
                />
              </div>
            </div>
          </div>

          <div className="mb-4">
            <div className="flex space-x-4">
              <div className="w-1/2">
                <label
                  htmlFor="workType"
                  className="block text-gray-700 font-semibold"
                >
                  Work Type:
                </label>
                <select
                  id="workType"
                  name="workType"
                  value={postJob.workType}
                  onChange={handleChange}
                  className="rounded-md border border-gray-300 p-2 w-full"
                >
                  <option value="Job">Job</option>
                  <option value="Internship">Internship</option>
                </select>
              </div>

              <div className="w-1/2">
                <label
                  htmlFor="applicationDeadline"
                  className="block text-gray-700 font-semibold"
                >
                  Application Deadline:
                </label>
                <input
                  type="date"
                  id="applicationDeadline"
                  name="applicationDeadline"
                  value={postJob.applicationDeadline}
                  onChange={handleChange}
                  className="rounded-md border border-gray-300 p-2 w-full"
                />
              </div>
            </div>
          </div>

          <div className="mb-4">
            <div className="flex space-x-4">
              <div className="w-1/2">
                <label
                  htmlFor="positions"
                  className="block text-gray-700 font-semibold"
                >
                  No of Positions:
                </label>
                <input
                  type="number"
                  id="positions"
                  name="noOfPositions"
                  value={postJob.noOfPositions}
                  onChange={handleChange}
                  className="rounded-md border border-gray-300 p-2 w-full"
                  min="0"
                />
              </div>
              <div className="mb-4">
                <div className="block text-gray-700 font-semibold">Perks:</div>
                {/* First row of checkboxes */}
                <div className="flex checkbox md:space-x-8 mb-4">
                  {[
                    { id: "week", label: "5 Days a Week" },
                    { id: "health", label: "Health Insurance" },
                    { id: "life", label: "Life Insurance" },
                    { id: "gym", label: "Gym Benefit" },
                    { id: "travel", label: "Travel Allowance" },
                  ].map((perk) => (
                    <div className="flex items-center space-x-4" key={perk.id}>
                      <input
                        type="checkbox"
                        className="rounded border border-gray-300"
                        value={perk.label} // Using label as value for better readability
                        name="perks" // This should match the key in your state object
                        checked={postJob.perks.includes(perk.label)} // Check if the perk is in the state array
                        onChange={handleChange}
                      />
                      <span className="ml-2">{perk.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="text-center mt-8">
            <button
              type="submit"
              className="bg-blue-500 hover-bg-blue-700 text-white font-bold py-2 px-4 rounded"
            >
              Post Job
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PostJob;
