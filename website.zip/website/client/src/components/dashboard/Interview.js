import React, { useState, useEffect, useRef } from "react";
import Modal from "../../components/dashboard/Modal";
import { getAllJobsPosted, getAllCandidatesApplied } from "../../service/api";
import "../customCss/applicant.css";

const Interview = () => {
  const [jobs, setJobs] = useState([]);
  const [jobId, setJobId] = useState("");
  const [candidatesData, setCandidatesData] = useState([]);
  const selectedCandidateRef = useRef();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState("");


  useEffect(() => {
    const token = getCookie();
    const getAllJobsPost = async (token) => {
      const getjobs = await getAllJobsPosted(token);
      setJobs(getjobs);
    };
    getAllJobsPost(token);
  }, []);

  useEffect(() => {
    const fetchCandidatesData = async () => {
      if (jobId) {
        const candidates = await getAllCandidatesApplied(jobId);
        setCandidatesData(candidates);
      }
    };
    fetchCandidatesData();
  }, [jobId]);

  const getCookie = () => {
    const cookieValue = document.cookie
      .split("; ")
      .find((row) => row.startsWith("token="));
    if (cookieValue) {
      return cookieValue.split("=")[1];
    } else {
      return null;
    }
  };

  const handleStatusChange = (event, candidate) => {
    const newStatus = event.target.value;
    setSelectedStatus(newStatus);

    // You may want to send an API request to update the status on the backend.
    // For now, just update the state locally.
    // Example: updateStatus(candidate.id, newStatus);
    console.log(`Candidate ${candidate.candidate.name} status changed to: ${newStatus}`);
  };


  const openModal = (candidate) => {
    selectedCandidateRef.current = candidate; 
    setIsModalOpen(true);
  };

  const closeModal = (candidate) => {
    selectedCandidateRef.current = null;
    setIsModalOpen(false);
  };
  const handleSelectChange = (event) => {
    setJobId(event.target.value);
  };
  return (
    <div className="bg-white border rounded-lg shadow-lg mb-3 p-5">
      {/* Top Section with Dropdown */}
      <div className="flex justify-between candidate-heading items-center">
        <div className="relative">
          <label
            className="text-2xl text-gray-700 font-semibold"
            htmlFor="jobRoles"
          >
            Job Roles
          </label>
          <select
            id="jobRoles"
            className="block appearance-none w-full bg-white border border-gray-300 text-gray-700 py-2 px-3 pr-8 rounded-lg leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
            onChange={handleSelectChange}
            value={jobId} // Controlled component to set the selected value
          >
            <option className="text-blue-900" value="">
              Select a job
            </option>
            {jobs.map((job) => (
              <option key={job._id} value={job._id}>
                {job.jobTitle}
              </option>
            ))}
          </select>
        </div>
        <div className="flex space-x-4 text-gray-600">
          {/* Abbreviations */}
          <div>
            Select <span className="font-boldx"> "Interview"</span> to inform
            student for interview round. <br />
            You can connect with candidate over E-Mail or Call for further
            discussion.
          </div>
        </div>
      </div>

      {/* Candidate Table */}
      <div className="overflow-x-auto mt-5">
        <table className="min-w-full bg-white table-auto">
          <thead>
            <tr>
              <th className="border border-gray-300 p-2">SNo.</th>
              <th className="border border-gray-300 p-2">Name</th>
              <th className="border border-gray-300 p-2">Email</th>
              <th className="border border-gray-300 p-2">Mobile No.</th>
              <th className="border border-gray-300 p-2">Score</th>
              <th className="border border-gray-300 p-2">PoW</th>
              <th className="border border-gray-300 p-2">Status</th>
            </tr>
          </thead>
          {candidatesData.length > 0 ? (
          <tbody>
            {candidatesData.map((candidate, index) => (
              <tr key={index}>
                <td className="border border-gray-300 p-2 text-center">
                  {index + 1}
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  {candidate.candidate.name}
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  {candidate.candidate.email}
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  {candidate.candidate.mobno}
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  {(
                    (candidate.candidate.role_related.score.ques1.score +
                      candidate.candidate.role_related.score.ques2.score) /
                      2 +
                    candidate.candidate.scoreExcel +
                    candidate.candidate.scoreAnalytical +
                    candidate.candidate.scoreReasoning +
                    (candidate.candidate.creative_related.score.ques1.score +
                      candidate.candidate.creative_related.score.ques2.score) /
                      2 +
                    candidate.candidate.resume_score
                  ).toFixed(2)}
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  <button
                    onClick={() => openModal(candidate)}
                    className="text-blue-500 hover:underline cursor-pointer"
                  >
                    View PoW
                  </button>
                  <Modal
                    isOpen={isModalOpen}
                    closeModal={() => closeModal()}
                    candidateRef={selectedCandidateRef}
                  />
                </td>
                <td className="border border-gray-300 p-2 text-center">
                <div className="relative">
                      <select
                        value={selectedStatus}
                        onChange={(event) => handleStatusChange(event, candidate)}
                        className="block appearance-none w-full bg-white border border-gray-300 text-gray-700 py-2 px-3 pr-8 rounded-lg leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                      >
                        <option value="">Select Status</option>
                        <option value="Interview" style={{ color: 'green' }}>
                          Interview
                        </option>
                        <option value="Not-Shortlisted" style={{ color: 'red' }}>
                          Not-Shortlisted
                        </option>
                      </select>
                      <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                        <svg
                          className="fill-current h-4 w-4"
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 20 20"
                        >
                          <path
                            d="M5 8l5 5 5-5z"
                          />
                        </svg>
                      </div>
                    </div>
                </td>
              </tr>
            ))}
            </tbody>
              ) : (
            <tbody>
              <tr>
                <td colSpan="7" className="border border-gray-300 p-2 text-center">
                  <p className="text-gray-500">No students applied till now. Please wait for 24 hours.</p>
                </td>
              </tr>
            </tbody>
          )}
        </table>    
      </div>
    </div>
  );
};

export default Interview;
