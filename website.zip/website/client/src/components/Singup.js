import React, { useState } from "react";
import login from "../images/login.jpg";
import axios from "axios";
function Signup() {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleSignUp = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost:8080/api/v1/registerCandidate",
        JSON.stringify({ email, password, otp }),
        { headers: { "Content-Type": "application/json" } }
      );
      console.log(response.data);
    } catch (error) {
      console.log("Error while signUp ", error.message);
      return error.response;
    }
  };

  return (
    <section className="bg-gray-50  min-h-full pt-16 flex items-center justify-center">
      {/* image */}
      <div className="md:block hidden w-1/2">
        <img className="rounded-2xl" src={login} />
      </div>
      {/* login container */}
      <div className="bg-gray-100 flex rounded-2xl shadow-lg max-w-3xl p-2 m-0 items-center">
        {/* form */}
        <div className="px-2 md:px-16">
          <h2 className="font-bold text-2xl text-blue-700">Register</h2>
          <p className="text-xs mt-4 text-blue-700">
            Create a new user with the E-mail:
          </p>

          <form action="" className="flex flex-col gap-4">
            <input
              className="p-2 mt-8 rounded-xl border"
              type="email"
              name="email"
              placeholder="Email"
              onChange={(e) => setEmail(e.target.value)}
              value={email}
            />
            <div className="relative">
              <input
                className="p-2 rounded-xl border w-full"
                type={showPassword ? "text" : "password"}
                name="password"
                placeholder="Password"
                onChange={(e) => setPassword(e.target.value)}
                value={password}
              />
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                fill="gray"
                className="bi bi-eye absolute top-1/2 right-3 -translate-y-1/2 cursor-pointer"
                viewBox="0 0 16 16"
                onClick={togglePasswordVisibility}
              >
                <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z" />
                <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z" />
              </svg>
            </div>
            <button
              className="bg-blue-700 rounded-xl text-white py-2 hover:scale-105 duration-300"
              onClick={handleSignUp}
            >
              Signup
            </button>
          </form>

          <div className="mt-3 px-4 text-xs flex justify-between items-center text-blue-700">
            <p>Do you have an account?</p>
            <button className="py-2 px-5 bg-blue-700 text-white border rounded-xl hover:scale-110 duration-300">
              Login
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Signup;
