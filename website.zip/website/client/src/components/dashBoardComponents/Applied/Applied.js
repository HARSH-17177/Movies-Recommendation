import React from "react";
import styles from "./applied.module.css";
const data = [
  {
    id: 1,
    companyName: "HiremeClub",
    role: "Senior Frontend Developer",
    status: "Selected",
  },
  {
    id: 2,
    companyName: "Zomato",
    role: "Fullstack Developer",
    status: "Rejected",
  },
  {
    id: 3,
    companyName: "Uber",
    role: "Junior Frontend Developer",
    status: "Waiting",
  },
  {
    id: 4,
    companyName: "Google",
    role: "Junior Backend Developer",
    status: "Rejected",
  },
];
const Applied = () => {
  // const status = "Selected";
  return (
    <table className={styles.table}>
      <thead>
        <tr>
          <th className={styles.header}>SN</th>
          <th className={styles.header}>Company Name</th>
          <th className={styles.header}>Role</th>
          <th className={styles.header}>Status</th>
        </tr>
      </thead>
      <tbody>
        {data.map((e) => (
          <tr key={e.id}>
            <td>{e.id}</td>
            <td>{e.companyName}</td>
            <td>{e.role}</td>
            <td
              className={
                e.status === "Selected"
                  ? styles.selected
                  : e.status === "Rejected"
                  ? styles.rejected
                  : styles.waiting
              }
            >
              {e.status}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default Applied;
