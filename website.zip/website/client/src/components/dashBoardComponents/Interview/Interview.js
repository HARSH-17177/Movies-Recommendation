import { Button } from "@chakra-ui/react";
import styles from "./interview.module.css";
import React from "react";
const data = [
  {
    id: 1,
    companyName: "HiremeClub",
    role: "Senior Frontend Developer",
  },
  {
    id: 2,
    companyName: "Zomato",
    role: "Fullstack Developer",
  },
  {
    id: 3,
    companyName: "Uber",
    role: "Junior Frontend Developer",
  },
  {
    id: 4,
    companyName: "Google",
    role: "Junior Backend Developer",
  },
];
const Interview = () => {
  return (
    <table className={styles.table}>
      <thead>
        <tr>
          <th className={styles.header}>SN</th>
          <th className={styles.header}>Company Name</th>
          <th className={styles.header}>Role</th>
          <th className={styles.header}>Date</th>
          <th className={styles.header}>Status</th>
        </tr>
      </thead>
      <tbody>
        {data.map((e) => (
          <tr key={e.id}>
            <td>{e.id}</td>
            <td>{e.companyName}</td>
            <td>{e.role}</td>
            <td>{<input className={styles.datetime} type="datetime-local" name="dob" />}
            </td>
            <td>{<button className={styles.btn}>Start</button>}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default Interview;
