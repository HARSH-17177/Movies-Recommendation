import React, { useState, useRef, useEffect } from "react";
// import { Navbar } from "../../../components/Navbar";
// import { Footer } from "../../Footer.js";
import { uploadFile, getSignedUrl } from "../../../service/api";
import axios from "axios";
const mimeType = 'video/webm; codecs="opus,vp8"';

export default function Stage2() {
  const videoRef = useRef(null);
  const liveVideoFeed = useRef(null);
  const mediaRecorder = useRef(null);
  const [url, setUrl] = useState("");
  const localVideoChunksRef = useRef([]);
  const [permission, setPermission] = useState(false);
  const [recordingStatus, setRecordingStatus] = useState("inactive");
  const [stream, setStream] = useState(null);
  const [recordedVideo, setRecordedVideo] = useState(null);
  const [videoChunks, setVideoChunks] = useState([]);
  const [videoBlob, setVideoBlob] = useState(null);
  const [randomQuestion, setRandomQuestion] = useState(null);
  const timerIdRef = useRef(null);
  const questionNumberRef = useRef(1);
  console.log("Component rendered");
  const startTimer = () => {
    // Clear any existing timer
    if (timerIdRef.current) {
      clearTimeout(timerIdRef.current);
    }

    // Start a new timer and store its ID
    const newTimerId = setTimeout(() => {
      console.log("Timer expired!");
      handleNextQuestion();
    }, 20000);

    timerIdRef.current = newTimerId;
  };

  const resetTimer = () => {
    console.log("Timer is resetting");
    // Clear the timer if it exists
    if (timerIdRef.current) {
      clearTimeout(timerIdRef.current);
      timerIdRef.current = null; // Reset the timer ID
    }
  };

  //to get the url where we are uploading

  const getURL = async () => {
    const response = await getSignedUrl();
    // console.log(response.url);
  };
  useEffect(() => {
    getURL();
  }, []);

  //when we get video then upload it to aws
  const AWSUpload = async (Blob, url) => {
    console.log("upload function start");
    if (Blob) {
      console.log(url);
      await uploadFile(url, Blob);
      setUrl(url.split("?")[0]);
      console.log("upload function end");
    }
  };
  const getNextQuestion = async () => {
    try {
      console.log("we will get mext question");
      const response = await axios.get(
        "http://localhost:8080/api/v1/fetch-json"
      );
      const data = response.data;
      const randomIndex = Math.floor(Math.random() * data.length);
      setRandomQuestion(data[randomIndex]);
      questionNumberRef.current += 1;
      console.log("Question nujm", questionNumberRef.current);

      await startRecording();
      console.log("started recording again");
    } catch (error) {
      console.error("Error fetching JSON:", error);
    }
  };

  const handleNextQuestion = async () => {
    if (questionNumberRef.current >= 5) {
      // End recording after 5 questions
      endRecording();
    } else {
      await stopRecording();
      await getNextQuestion();
    }
  };

  const getCameraPermission = async () => {
    setRecordedVideo(null);

    if ("MediaRecorder" in window) {
      try {
        const videoConstraints = {
          audio: false,
          video: true,
        };
        const audioConstraints = { audio: true };

        const audioStream = await navigator.mediaDevices.getUserMedia(
          audioConstraints
        );
        const videoStream = await navigator.mediaDevices.getUserMedia(
          videoConstraints
        );

        setPermission(true);

        const combinedStream = new MediaStream([
          ...videoStream.getVideoTracks(),
          ...audioStream.getAudioTracks(),
        ]);

        setStream(combinedStream);

        liveVideoFeed.current.srcObject = videoStream;
      } catch (err) {
        alert(err.message);
      }
    } else {
      alert("The MediaRecorder API is not supported in your browser.");
    }
  };

  const startRecording = async () => {
    resetTimer();
    setRecordingStatus("recording");

    const media = new MediaRecorder(stream, { mimeType });
    mediaRecorder.current = media;
    mediaRecorder.current.start();

    mediaRecorder.current.ondataavailable = (event) => {
      if (typeof event.data === "undefined") return;
      if (event.data.size === 0) return;
      localVideoChunksRef.current = [];
      localVideoChunksRef.current.push(event.data);
      console.log("pushing the chunks");
    };

    setVideoChunks(localVideoChunksRef.current);
    console.log("video chunks ONE:", localVideoChunksRef.current);
    // setTimeout(async () => {
    //   console.log("video chunks 2:", localVideoChunks);
    //   handleNextQuestion();
    // }, 20000);
    startTimer();
    console.log("we have the URL: ", url);
  };

  const stopRecording = () => {
    console.log("stopping recording in stopRecording function START");
    setPermission(false);
    setRecordingStatus("inactive");
    mediaRecorder.current.stop();

    mediaRecorder.current.onstop = async () => {
      const vidBlob = new Blob(localVideoChunksRef.current, { type: mimeType });
      const videoUrl = URL.createObjectURL(vidBlob);
      console.log("this is setted video :", videoChunks);
      setRecordedVideo(videoUrl);
      setVideoBlob(vidBlob);
      setVideoChunks([]);
      console.log(
        "Video Blob and chunks:",
        vidBlob,
        localVideoChunksRef.current
      );
      const response = await getSignedUrl();
      console.log("Before calling upload function in stop recording");
      await AWSUpload(vidBlob, response.url);
      console.log("After the Upload function in Stop recording");
    };
  };

  const endRecording = () => {
    console.log("end recording");
    setPermission(false);
    setRecordingStatus("inactive");
    mediaRecorder.current.stop();
    resetTimer();
    mediaRecorder.current.onstop = async () => {
      const vidBlob = new Blob(localVideoChunksRef.current, { type: mimeType });
      const videoUrl = URL.createObjectURL(vidBlob);
      setRecordedVideo(videoUrl);
      setVideoBlob(vidBlob);
      setVideoChunks([]);
      const response = await getSignedUrl();
      console.log("Before calling upload function in end recording");
      await AWSUpload(vidBlob, response.url);
      console.log("After the Upload function in end recording");
    };
  };
  return (
    <>
      
      <p>{recordingStatus}</p>
      <div>
        {randomQuestion ? (
          <div>
            <h2>Random Interview Question</h2>
            <p>{randomQuestion.question}</p>
            <p>Category: {randomQuestion.category}</p>
          </div>
        ) : (
          <p>Loading random question...</p>
        )}
      </div>
      <div>
        <div className="flex flex-col items-center justify-center min-h-screen min-w-full">
          <div className="w-72 h-48 sm:w-3/5 sm:h-auto md:aspect-w-16/9 sm:aspect-h-9/16 bg-gray-500">
            <video ref={liveVideoFeed} autoPlay className="live-player"></video>
          </div>

          <div className="mt-4">
            {!permission ? (
              <button
                onClick={getCameraPermission}
                className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 mr-2 rounded"
              >
                Get Camera
              </button>
            ) : null}
            {permission && recordingStatus === "inactive" ? (
              <button
                onClick={startRecording}
                className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 mr-2 rounded"
              >
                Start Test
              </button>
            ) : null}
            {recordingStatus === "recording" ? (
              <button
                onClick={endRecording}
                className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
              >
                End Test
              </button>
            ) : null}

            {recordingStatus === "recording" ? (
              <button
                onClick={handleNextQuestion}
                className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"
              >
                Next Question
              </button>
            ) : null}
          </div>
        </div>
        <h3>Video rendered using AWS link</h3>

        {videoBlob && (
          <video width="400" height="200" controls src={url}>
            Browser not supported
          </video>
        )}
      </div>
     
    </>
  );
}
