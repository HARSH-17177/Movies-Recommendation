import { useState } from "react";
import favicon from "../images/favicon.png";

export const Navbar = ({ isSticky }) => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
  
    const handleAvatarClick = () => {
      setIsMenuOpen(!isMenuOpen);
    };
  
    const handleProfileClick = () => {
    //  console.log('Profile clicked');
      setIsMenuOpen(false);
    };
  
    const handleLogoutClick = () => {
    //  console.log('Logout clicked');
      setIsMenuOpen(false);
    };

  const navbarStyle = isSticky ? "sticky top-0 z-10 p-2" : "relative";

  return (
    <div className={`py-5 z-10 mx-auto bg-gray-50 sm:max-w-xl md:max-w-full lg:max-w-screen-xl  ${navbarStyle}`}>
      <div className="relative flex items-center justify-between">
        <a
          href="/"
          aria-label="HiremeClub Logo"
          title="HiremeClub Logo"
          className="inline-flex items-center"
        >
          <img src={favicon} alt="Logo" className="h-16 w-16 mr-0" />
          <span className="ml-2 text-xl font-bold tracking-wide text-gray-800 font-custom">
            Hireme<span className="text-blue-500">Club</span>
          </span>
        </a>

        {/*Code for Avatar Profile and Logout*/}
        <div className="flex items-center space-x-8 lg:flex drop-shadow-2xl">
          <button
            className="flex items-center focus:outline-none "
            onClick={handleAvatarClick}
          >
            <img
              className="h-16 w-16 rounded-full object-cover hover:shadow-lg4"
              src={favicon}
              alt="Avatar"
            />
          </button>

          {/*Code for Logout Options*/}
          {isMenuOpen && (
            <ul className="absolute right-0 mt-36 w-36 bg-white border rounded-lg shadow-md drop-shadow-2xl">
              <li className="block text-bottom px-4 py-2 hover:bg-gray-100">
                <button onClick={handleProfileClick}>Profile</button>
              </li>
              <li className="block text-bottom px-4 py-2 hover:bg-gray-100">
                <button onClick={handleLogoutClick}>Logout</button>
              </li>
            </ul>
          )}
        </div>
      </div>
    </div>
  );
};