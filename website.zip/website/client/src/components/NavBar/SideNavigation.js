const SideNavigation = () => {
  return (
    <div>
      <ul>
        <li>
          <a href="/">Home</a>
        </li>
        <li>
          <a href="/#">Comapny Profile</a>
        </li>
        <li>
          <a href="/#">Job Offered</a>
        </li>
        <li>
          <a href="/#">Applications Received</a>
        </li>
        <li>
          <a href="/#">Messages</a>
        </li>
      </ul>
      <div></div>
    </div>
  );
};

export default SideNavigation;
