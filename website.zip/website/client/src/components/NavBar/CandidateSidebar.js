import React, { useState } from 'react';
import '../customCss/candidateSidebar.css';
import {
  PresentationChartLineIcon,
  ChatBubbleLeftRightIcon,
  BriefcaseIcon,
  InboxIcon,
  StarIcon,
  UserCircleIcon,
} from '@heroicons/react/24/outline';
import { NavLink } from 'react-router-dom';

const Sidebar = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div className="contain flex h-screen rounded">
      <button onClick={toggleSidebar} className="md:hidden absolute top-6 right-3 z-10 p-3">
        {isSidebarOpen ? (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth="1.5"
            stroke="currentColor"
            className="w-6 h-6"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
          </svg>
        ) : (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth="1.5"
            stroke="currentColor"
            className="w-6 h-6"
          >
            <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
          </svg>
        )}
      </button>

      <nav className={`bg-white md:w-64 rounded-2xl side-navigation border-r ${isSidebarOpen ? 'block' : 'hidden'} md:block`}>
        <ul className="text-gray-700 px-8">
          <li className="hover:bg-gray-200 transition-transform transform-gpu hover:-translate-y-1 p-4 rounded-xl mt-4">
            <NavLink to="/dashboard" className="flex items-center">
              <PresentationChartLineIcon className="h-6 w-6 mr-2 inline" />
              Dashboard
            </NavLink>
          </li>
          <li className="hover:bg-gray-200 transition-transform transform-gpu hover:-translate-y-1 p-4 rounded-xl">
            <NavLink to="/dashboard/interview" className="flex items-center">
              <ChatBubbleLeftRightIcon className="h-6 w-6 mr-2 inline" />
              Interview
            </NavLink>
          </li>
          <li className="hover:bg-gray-200 transition-transform transform-gpu hover:-translate-y-1 p-4 rounded-xl">
            <NavLink to="/jobs" className="flex items-center">
              <BriefcaseIcon className="h-6 w-6 mr-2 inline" />
              Jobs
            </NavLink>
          </li>
          <li className="hover:bg-gray-200 transition-transform transform-gpu hover:-translate-y-1 p-4 rounded-xl">
            <NavLink to="/dashboard/inbox" className="flex items-center">
              <InboxIcon className="h-6 w-6 mr-2 inline" />
              Inbox
            </NavLink>
          </li>
          <li className="hover:bg-gray-200 transition-transform transform-gpu hover:-translate-y-1 p-4 rounded-xl">
            <NavLink to="/dashboard/wishlist" className="flex items-center">
              <StarIcon className="h-6 w-6 mr-2 inline" />
              Wishlist
            </NavLink>
          </li>
          <li className="hover:bg-gray-200 transition-transform transform-gpu hover:-translate-y-1 p-4 rounded-xl">
            <NavLink to="/dashboard/profile" className="flex items-center">
              <UserCircleIcon className="h-6 w-6 mr-2 inline" />
              Profile
            </NavLink>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default Sidebar;
