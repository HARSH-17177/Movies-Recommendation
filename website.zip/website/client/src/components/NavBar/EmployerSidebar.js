import React, { useState } from "react";
import "../customCss/candidateSidebar.css";

import {
  PresentationChartLineIcon,
  ChatBubbleLeftRightIcon,
  BriefcaseIcon,
  InboxIcon,
  UserGroupIcon,
  CogIcon,
} from "@heroicons/react/24/outline";
import { NavLink } from "react-router-dom";

const Sidebar = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div className="contain flex h-screen rounded ">
      {/* Mobile Sidebar Toggle Button */}
      <button
        onClick={toggleSidebar}
        className="md:hidden absolute top-6 right-3 z-10 p-3"
      >
        {isSidebarOpen ? (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            stroke-width="1.5"
            stroke="currentColor"
            className="w-6 h-6"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"
            />
          </svg>
        ) : (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            stroke-width="1.5"
            stroke="currentColor"
            className="w-6 h-6"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"
            />
          </svg>
        )}
      </button>

      {/* Sidebar */}
      <nav
        className={`bg-white  md:w-64 rounded-2xl side-navigation border-r ${
          isSidebarOpen ? "block" : "hidden"
        } md:block`}
      >
        <ul className="text-gray-700 px-8">
          <NavLink to="/emp-dashboard/">
            <li className="hover:bg-gray-200 hover:text-blue-600  transition-transform transform-gpu hover:-translate-y-1 p-4 cursor-pointer  rounded-xl mt-4">
              <PresentationChartLineIcon className="h-6 w-6 mr-2 inline" />
              Dashboard
            </li>
          </NavLink>

          <NavLink to="/emp-dashboard/interview">
            <li className="hover:bg-gray-200 hover:text-blue-600 transition-transform transform-gpu hover:-translate-y-1 p-4 cursor-pointer  rounded-xl">
              {" "}
              <ChatBubbleLeftRightIcon className="h-6 w-6 mr-2 inline" />
              Interview
            </li>
          </NavLink>

          <NavLink to="/emp-dashboard/postjob">
          <li className="hover:bg-gray-200 hover:text-blue-600 transition-transform transform-gpu hover:-translate-y-1 p-4 cursor-pointer  rounded-xl">
              {" "}
              <BriefcaseIcon className="h-6 w-6 mr-2 inline" />
              Post a Job
          </li>
          </NavLink>

          <NavLink to="/emp-dashboard/comingsoon">
          <li className="hover:bg-gray-200 hover:text-blue-600 transition-transform transform-gpu hover:-translate-y-1 p-4 cursor-pointer  rounded-xl">
              <InboxIcon className="h-6 w-6 mr-2 inline" />
              Inbox
          </li>
          </NavLink>

          <NavLink to="/emp-dashboard/candidates">
          <li className="hover:bg-gray-200 hover:text-blue-600 transition-transform transform-gpu hover:-translate-y-1 p-4 cursor-pointer  rounded-xl">
              {" "}
              <UserGroupIcon className="h-6 w-6 mr-2 inline" />
              Candidates
          </li>
          </NavLink>

          <NavLink to="/emp-dashboard/settings">
          <li className="hover:bg-gray-200 hover:text-blue-600 transition-transform transform-gpu hover:-translate-y-1 p-4 cursor-pointer  rounded-xl">
              <CogIcon className="h-6 w-6 mr-2 inline" />
              Settings
          </li>
          </NavLink>

        </ul>
      </nav>

    </div>
  );
};

export default Sidebar;
