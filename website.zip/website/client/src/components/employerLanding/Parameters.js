import React from "react";
import analytics from "../../images/parameters/analytics.png";
import creativity from "../../images/parameters/creativity.png";
import communication from "../../images/parameters/communication.png";
import confidence from "../../images/parameters/confidence.png";
import realLife from "../../images/parameters/realLife.png";
import excel from "../../images/parameters/excel.png";
import subject from "../../images/parameters/subject.png";
import problem from "../../images/parameters/problem.png";
import { Footer } from "../Footer";

export default function Parameters() {
  return (
    <div className="px-4 py-16 mx-auto sm:max-w-xl md:max-w-full lg:max-w-screen-xl md:px-24 lg:px-8 lg:py-16">
      <div className="max-w-xl mb-10 md:mx-auto sm:text-center lg:max-w-2xl md:mb-12">
        <div>
          <p className="inline-block px-3 py-px text-sm font-bold tracking-wider text-blue-800 rounded-full bg-blue-100">
            Proof-of-Work
          </p>
        </div>
        <h2 className="max-w-lg mb-6 font-sans text-3xl font-bold leading-none tracking-tight text-gray-900 sm:text-4xl md:mx-auto">
          Parameters
        </h2>
      </div>
      <div className="grid row-gap-8 sm:row-gap-0 sm:grid-cols-2 lg:grid-cols-4">
        <div className="p-8 border-b-2 transition-transform transform hover:scale-105 hover:shadow-lg sm:border-r-2">
          <div className="max-w-md text-center">
            <div className="flex items-center justify-center w-16 h-16 mx-auto mb-4  sm:w-16 sm:h-16">
              <img src={subject} alt="Subject Expert Icon" />
            </div>
            <h6 className="mb-2 font-semibold leading-5">SUBJECT KNOWLEDGE</h6>
          </div>
        </div>
        <div className="p-8 border-b-2 transition-transform transform hover:scale-105 hover:shadow-lg lg:border-r-2">
          <div className="max-w-md text-center">
            <div className="flex items-center justify-center w-16 h-16 mx-auto mb-4  sm:w-16 sm:h-16">
              <img src={excel} alt="Excel Knowledge Icon" />
            </div>
            <h6 className="mb-2 font-semibold leading-5">EXCEL KNOWLEDGE</h6>
          </div>
        </div>
        <div className="p-8 border-b-2 transition-transform transform hover:scale-105 hover:shadow-lg sm:border-r-2 lg:border-r-2">
          <div className="max-w-md text-center">
            <div className="flex items-center justify-center w-16 h-16 mx-auto mb-4  sm:w-16 sm:h-16">
              <img src={analytics} alt="Analytical Skill Icon" />
            </div>
            <h6 className="mb-2 font-semibold leading-5">ANALYTICAL SKILL</h6>
          </div>
        </div>
        <div className="p-8 border-b-2 transition-transform transform hover:scale-105 hover:shadow-lg lg:border-b-2 lg:border-r-2">
          <div className="max-w-md text-center">
            <div className="flex items-center justify-center w-16 h-16 mx-auto mb-4  sm:w-16 sm:h-16">
              <img src={problem} alt="Problem Solving Skill Icon" />
            </div>
            <h6 className="mb-2 font-semibold leading-5">
              PROBLEM SOLVING SKILL
            </h6>
          </div>
        </div>
        <div className="p-8 border-b-2 transition-transform transform hover:scale-105 hover:shadow-lg sm:border-b-2 sm:border-r-2">
          <div className="max-w-md text-center">
            <div className="flex items-center justify-center w-16 h-16 mx-auto mb-4  sm:w-16 sm:h-16">
              <img src={realLife} alt="Real Life Skill" />
            </div>
            <h6 className="mb-2 font-semibold leading-5">
              REAL LIFE SITUATION
            </h6>
          </div>
        </div>
        <div className="p-8 border-b-2 transition-transform transform hover:scale-105 hover:shadow-lg sm:border-b-2 sm:border-r-2">
          <div className="max-w-md text-center">
            <div className="flex items-center justify-center w-16 h-16 mx-auto mb-4  sm:w-16 sm:h-16">
              <img src={communication} alt="Communication Skill Icon" />
            </div>
            <h6 className="mb-2 font-semibold leading-5">
              COMMUNICATION SKILL
            </h6>
          </div>
        </div>
        <div className="p-8 border-b-2 transition-transform transform hover:scale-105 hover:shadow-lg sm:border-b-2 sm:border-r-2">
          <div className="max-w-md text-center">
            <div className="flex items-center justify-center w-16 h-16 mx-auto mb-4  sm:w-16 sm:h-16">
              <img src={confidence} alt="Confidence Skill Icon" />
            </div>
            <h6 className="mb-2 font-semibold leading-5">CONFIDENCE LEVEL</h6>
          </div>
        </div>
        <div className="p-8 border-b-2 transition-transform transform hover:scale-105 hover:shadow-lg sm:border-b-2 sm:border-r-2">
          <div className="max-w-md text-center">
            <div className="flex items-center justify-center w-16 h-16 mx-auto mb-4  sm:w-16 sm:h-16">
              <img src={creativity} alt="Creativity Skill" />
            </div>
            <h6 className="mb-2 font-semibold leading-5">CREATIVITY</h6>
          </div>
        </div>
      </div>
      {/* <Footer className="footer" showBookingSlot={true} /> */}
    </div>
  );
}
