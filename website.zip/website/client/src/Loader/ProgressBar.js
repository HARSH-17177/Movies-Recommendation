import React, { useEffect } from "react";
import { ProgressBar } from "react-loader-spinner";
import { useNavigate } from "react-router-dom";

const ProgressBarComponent = ({destination}) => {
  const navigate = useNavigate();

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      navigate(destination);
    }, 500);

    return () => {
      // Clear the timeout to prevent navigation if the component unmounts before 2 seconds
      clearTimeout(timeoutId);
    };
  }, [navigate]);

  return (
    <div className="progress-bar-wrapper flex items-center justify-center h-screen">
      <ProgressBar
        height={120}
        width={120}
        ariaLabel="progress-bar-loading"
        borderColor="#000000"
        barColor="#1E88E5"
      />
    </div>
  );
};

export default ProgressBarComponent;
