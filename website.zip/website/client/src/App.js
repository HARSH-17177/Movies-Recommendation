import React from "react";
import { Routes, Route } from "react-router-dom";
import Landing from "./pages/portal/Landing";
import EmployerLanding from "./pages/EmployerLanding";
import Stage3 from "./pages/Stage3";
import Stage2 from "./pages/Stage2";
import Stage1 from "./pages/Stage1";
import CreativeIdea from "./pages/creativeIdea";
import JobDetails from "./pages/JobDetails/JobDetails";
import Login from "./pages/Login";
import ResumeData from "./pages/ResumeData.js";
import Listing from "./pages/portal/Listing";
import ApplicantDashboard from "./pages/Dashboard/ApplicantDashboard.js";
import EmployerDashboard from "./pages/Dashboard/EmployerDashboard";
import EmployerLogin from "./pages/EmployerLogin";
import InstructionMcq from './pages/Instructions/InstructionMCQ.js'
import InstructionVideo from "./pages/Instructions/InstructionVideo.js";
import Mcq from "./pages/Mcq";
import ErrorPage from "./pages/ErrorPage.js";
import PrivateRoute from "./context/PrivateRoute.js";
import EmpPrivateRoute from "./context/EmpPrivateRoute.js";
import { EmpAuthProvider } from "./context/EmpAuthProvider.js";
import { AuthProvider } from "./context/AuthProvider.js";
import Applicant from "./components/dashboard/Applicant.js";
import Interview from "./components/dashboard/Interview.js";
import ComingSoon from "./components/ComingSoon.js";
import Wishlist from "./components/dashboard/Wishlist.js";
import ProfileForm from "./components/dashboard/Profile.js";
import Settings from "./components/dashboard/Settings.js";
import Candidates from "./components/dashboard/Candidates.js";
import PostJob from "./components/dashboard/PostJob.js";
import Employer from "./components/dashboard/Employer.js";
import InsCreative from "./pages/Instructions/InsCreative.js";
import InStage3 from "./pages/Instructions/InsStage3.js";
import EmployerDetails from "./pages/EmployerDetails.js";

function App() {
  return (
    <Routes>
      <Route
        path="/"
        element={
          <EmpAuthProvider>
            <AuthProvider>
              <Landing />
            </AuthProvider>
          </EmpAuthProvider>
        }
      />
      <Route
        path="/hire"
        element={
          <AuthProvider>
            <EmpAuthProvider>
              <EmployerLanding />
            </EmpAuthProvider>
          </AuthProvider>
        }
      />
      <Route
        path="/jobs"
        element={
          <AuthProvider>
            <EmpAuthProvider>
              <Listing />
            </EmpAuthProvider>
          </AuthProvider>
        }
      />
      <Route
        path="/jobs/details/:id"
        element={
          <AuthProvider>
            <EmpAuthProvider>
              <JobDetails />
            </EmpAuthProvider>
          </AuthProvider>
        }
      />

      <Route path="/login" element={<Login />} />
      {/*These are all the Protected Routes which open after login */}
      <Route
        path=""
        element={
          <AuthProvider>
            <PrivateRoute />
          </AuthProvider>
        }
      >
        <Route path="/stage1" element={<Stage1 />} />
        <Route path="/stage2" element={<Stage2 />} />
        <Route path="/stage3" element={<Stage3 />} />
        <Route path="/idea" element={<CreativeIdea />} />
        <Route path="/resume-data" element={<ResumeData />} />
        <Route path="/instruction-video" element={<InstructionVideo />} />
        <Route path="/instruction-mcq" element={<InstructionMcq />} />
        <Route path="/insidea" element={<InsCreative/>} />
        <Route path="/insstage3" element={<InStage3/>} />
        <Route path="/mcq" element={<Mcq />} />
        <Route path="/dashboard/" element={<ApplicantDashboard />}>
          <Route path="" element={<Applicant />} />
          <Route path="interview" element={<ComingSoon />} />
          <Route path="inbox" element={<ComingSoon />} />
          <Route path="wishlist" element={<Wishlist />} />
          <Route path="profile" element={<ProfileForm />} />
        </Route>
      </Route>

      <Route path="/emp-login" element={<EmployerLogin />} />
      {/*All protected Routes to Login into Employer side */}
      <Route
        path=""
        element={
          <EmpAuthProvider>
            <EmpPrivateRoute />
          </EmpAuthProvider>
        }
      >
        <Route path="/empDetails" element={<EmployerDetails />} />
        <Route path="/emp-dashboard/*" element={<EmployerDashboard />}>
          <Route path="" element={<Employer />} />
          <Route path="postjob" element={<PostJob />} />
          <Route path="comingsoon" element={<ComingSoon />} />
          <Route path="interview" element={<Interview />} />
          <Route path="candidates" element={<Candidates />} />
          <Route path="settings" element={<Settings />} />
        </Route>
      </Route>
      <Route path="*" element={<ErrorPage />} />
      {/* Add more routes as needed */}
    </Routes>
  );
}

export default App;
